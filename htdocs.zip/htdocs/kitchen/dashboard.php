<?php
    require 'logincheck.php';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<table>
		<tr>
			<th>ORDER</th>
		</tr>
	</table>
	<p id="warning"></p>
	<p id="content2"></p>
</body>
<script type="text/javascript">
	$("#content2").load("kitchen/order.php");
</script>
</html>