<!DOCTYPE html>
<html>
<head>
	<title>Order</title>
</head>
<body>
	<p id="load"></p>
</body>
<script type="text/javascript">
	kitchenlist();
	setInterval(kitchenlist ,20000);
	function kitchenlist() {
		$("#load").load("kitchen/orderdb.php",{
			load : "kitchen"
		});
	}
	function acceptorder(bm){
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/g);
		if (bmname[0] == "accept") {
			$("#load").load("kitchen/orderdb.php",{
				orderid : bmid[0]
			});
		}
	}
</script>
</html>