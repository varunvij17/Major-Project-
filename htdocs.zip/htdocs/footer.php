<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<table>
		<tr>
			<td id="about" class="footertd">
				<p>RESTAURANT INVENTORY MANAGEMENT SYSTEM</p>
				<p>100 years of history. Countless rewards. With an unshakeable credo and corporate philosophy of un-wavering commitment to service, both in our hotels and in our communities, RESTAURANT INVENTORY MANAGEMENT SYSTEM has been recognized with numerous awards for being the gold standard of hospitality.</p>
			</td>
			<td id="contact" class="footertd">
				<p>Contact Us: 800-222-6527</p>
				<p>Email: rims@gmail.com</p>
			</td>
		</tr>
		<tr>
			<td colspan="2" id="policy"></td>
		</tr>
		<tr>
			<td colspan="2" id="copyrights"></td>
		</tr>
	</table>
</body>
</html>