<?php
	require 'admin/yesterdaydb.php';
	yesterday();
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/theme.css">
</head>
<body>
	<table>
		<tr>
			<td colspan="2"><a class="webname" onclick="window.location.href='/'">Restaurant Inventory Management System</a></td>
			<td></td>
			<td id="loginout" class="loginout"></td>
		</tr>
		<tr>
			<td colspan="4">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a class="nav" onclick="window.location.href='/'">Home</a>
				<a class="nav" onclick="window.location.href='/chef.php'">Chef</a>
				<a class="nav" onclick="window.location.href='/kitchen.php'">Kitchen</a>
				<a class="nav" onclick="window.location.href='/rece_waiter.php'">Waiter / Reception</a>
			</td>
		</tr>
	</table>
</body>
<?php
	if (isset($_SESSION["username"]) && isset($_SESSION["password"]) && isset($_SESSION["who"])) {
		if ($_SESSION["who"] == "admin") {
			$str = "<span>".$_SESSION["username"]."</span><br><a name='logout' class='loginoutclick' onclick='logout(this.name)'>Logout</a>";
			echo '<script type="text/javascript">$("#loginout").html("'.$str.'")</script>';
		}
		if(isset($_SESSION["hotelid"])){
			$str = "<span>".$_SESSION["username"]."</span><br><a name='logout' class='loginoutclick' onclick='logout(this.name)'>Logout</a>";
			echo '<script type="text/javascript">$("#loginout").html("'.$str.'")</script>';
		}
	}
?>
<script type="text/javascript">
	function logout(bm){
		if(bm == "logout"){
			$.post("logout.php");
			location.reload();
		}
	}
</script>
</html>