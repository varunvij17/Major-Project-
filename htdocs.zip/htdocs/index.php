<?php
    //$_SESSION["username"]
    //$_SESSION["password"]
    //$_SESSION["hotelid"]
    //$_SESSION["who"]
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Hotel Monitor</title>
	<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="js/cookie.js"></script>
</head>
<body>
<header id="header" class="head">
	<?php
		require 'header.php';
	?>
</header>
		<table id="content1" class="content1">
			<tr>
				<td id="img1" colspan="2"></td>
			</tr>
			<tr>
				<td colspan="2" class="imgloopswitch">
					<a name="ia1" onclick="imgloopclk(this.name)">&#x26AC;</a>
					<a name="ia2" onclick="imgloop(this.name)">&#x26AC;</a>
					<a name="ia3" onclick="imgloop(this.name)">&#x26AC;</a>
				</td>
			</tr>
			<tr>
				<td><img class="contentimg" src="img/WABH_Spa-0001_1024x549.jpg">
					<p class="description">Rejuvenate with La Prairie’s world-renowned signature products, age-defying science and skin care.</p>
				</td>
				<td><img class="contentimg" src="img/JGBH_Food_Sashimi_Platter-0001-675x745.jpg">
					<p class="description">Try the finest dining at Jean-Georges Beverly Hills.</p>
				</td>
			</tr>
			<tr>
				<td><img class="contentimg" src="img/Pool-Cabanas-Low-675x745.jpg">
					<p class="description">Find inspiring ways to enjoy your escape.</p>
				</td>
				<td><img class="contentimg" src="img/Villa-Bedroom-315-Low-1395x745.jpg">
					<p class="description">Experience state-of-the-art technology, private balconies and floor-to-ceiling windows in every room.</p>
				</td>
			</tr>
		</table>
<footer id="footer">
	<?php
		require 'footer.php';
	?>
</footer>
</body>
<script type="text/javascript">http://localhost/img/WABH_Exterior_0005-2_1080x720.jpg
	var ia = ["img/WABH_Exterior_0005-2_1080x720.jpg","img/WABH_Lobby_2111x1134-1920x1080.jpg","img/WABH_Pool_0001-1920x1080.jpg"];
	var iaInc = 0;
	imgloop();
	var imgtime = setInterval(imgloop ,10000);
	function imgloop(){
		var str = "<img class='imgloopimg' src='"+ia[iaInc]+"' />";
		$("#img1").html(str);
		if(iaInc == 2){
			iaInc = 0;
		}else{
			iaInc++;
		}
	}
	function imgloopclk(bm){
		if(bm == "ia1"){
			iaInc = 0;
			clearInterval(imgtime);
			imgloop();
			imgtime = setInterval(imgloop ,10000);
		}
		if(bm == "ia2"){
			iaInc = 1;
			clearInterval(imgtime);
			imgloop();
			imgtime = setInterval(imgloop ,10000);
		}
		if(bm == "ia3"){
			iaInc = 2;
			clearInterval(imgtime);
			imgloop();
			imgtime = setInterval(imgloop ,10000);
		}
	}
	document.getElementById("content1").style.paddingTop = document.getElementById("header").clientHeight+"px";
	if(window.innerHeight > document.getElementById("content1").clientHeight){
		document.getElementById("content1").style.paddingBottom = (window.innerHeight-document.getElementById("content1").clientHeight)+"px";
	}
	document.getElementById("content1").style.marginBottom = "0px";
</script>
</html>