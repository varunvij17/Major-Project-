<?php
    session_start();
    if (isset($_SESSION["who"])) {
    	if ($_SESSION["who"] == "admin") {
    		if ($_SERVER['PHP_SELF'] != "/admin.php") {
    			header("location:admin.php");
    			exit();
    		}
    	}
    	if ($_SESSION["who"] == "chef") {
    		if ($_SERVER['PHP_SELF'] != "/chef.php") {
    			header("location:chef.php");
    			exit();
    		}
    	}
    	if ($_SESSION["who"] == "others") {
    		if ($_SERVER['PHP_SELF'] != "/rece_waiter.php") {
    			header("location:rece_waiter.php");
    			exit();
    		}
    	}
    	if ($_SESSION["who"] == "kitchen") {
    		if ($_SERVER['PHP_SELF'] != "/kitchen.php") {
    			header("location:kitchen.php");
    			exit();
    		}
    	}
    }
?>