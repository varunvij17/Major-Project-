<?php
	session_start();
    date_default_timezone_set('Asia/Kolkata');
    if (isset($_POST["load"])) {
    	perishable_items();
    }
    if (isset($_POST["srcitem"])) {
    	perishable_items_src($_POST["srcitem"]);
    }
    if (isset($_POST["item"]) && isset($_POST["weight"]) && isset($_POST["unit"]) && isset($_POST["cost"])) {
    	$weight = $_POST["weight"];
    	$unit = "";
    	if (($_POST["unit"] == "g") || ($_POST["unit"] == "m")) {
    		$weight = $weight / 1000;
    	}
    	if (($_POST["unit"] == "g") || ($_POST["unit"] == "k")) {
    		$unit = "Kg";
    	}
    	if (($_POST["unit"] == "m") || ($_POST["unit"] == "l")) {
    		$unit = "L";
    	}
    	perishable_add($_POST["item"], $weight, $unit, $_POST["cost"]);
    }
    if (isset($_POST["itemid_update"]) && isset($_POST["weight_update"]) && isset($_POST["cost_update"]) && isset($_POST["reduce_weight"]) && isset($_POST["reduce_cost"])) {
    	perishable_update($_POST["itemid_update"], $_POST["weight_update"], $_POST["cost_update"], $_POST["reduce_weight"], $_POST["reduce_cost"]);
    }
    function perishable_update($itemid, $weight, $cost, $reduceweight, $reducecost) {
    	$hotid = $_SESSION["hotelid"];
    	$perish_date = date("d-m-Y");
        $resetdamagedate = date("Ymd");
		require 'dbconnect.php';
		$sql = "UPDATE ingredients SET weight=$reduceweight, cost=$reducecost, incdate='$perish_date', damageweight=damageweight+$weight, damagecost=damagecost+$cost, resetdamagedate='$resetdamagedate' WHERE incid=$itemid AND hotid=$hotid";
		if (mysqli_query($conn, $sql)) {
            //echo "Record updated successfully";
            echo "done";
        } else {
            //echo "Error updating record: " . mysqli_error($conn);
        }
        $conn->close();
        exit();
    }
    function perishable_items_src($srcitem) {
    	$hotid = $_SESSION["hotelid"];
    	$i = 0;
    	require 'dbconnect.php';
    	$sql = "SELECT * FROM perishable WHERE perishable LIKE '%$srcitem%' AND perishhotid=$hotid";
    	$result = mysqli_query($conn,$sql);
    	$str = "<table class=\"listtable\">";
    	$str .= "<tr>";
    	$str .= "<th>Sr no</th>";
    	$str .= "<th>Items</th>";
    	$str .= "<th>Weight(Kg / L)</th>";
    	$str .= "<th>Unit</th>";
    	$str .= "<th>Cost</th>";
    	$str .= "<th>Date</th>";
    	$str .= "<th>Updae</th>";
    	$str .= "</tr>";
    	if(mysqli_num_rows($result) > 0) {
    		while ($row = mysqli_fetch_assoc($result)) {
    			$i++;
    			$str .= "<tr id=\"perishtr".$row["incid"]."\">";
    			$str .= "<td id=\"srno".$row["incid"]."\">".$i."</td>";
    			$str .= "<td id=\"itemtd".$row["incid"]."\">".$row["perishable"]."</td>";
    			$str .= "<td id=\"weighttd".$row["incid"]."\">".$row["perishweight"]."</td>";
    			$str .= "<td id=\"unittd".$row["incid"]."\">".$row["perishunit"]."</td>";
    			$str .= "<td id=\"costtd".$row["incid"]."\">".$row["perishcost"]."</td>";
    			$str .= "<td id=\"datetd".$row["incid"]."\">".$row["perishdate"]."</td>";
    			$str .= "<td id=\"buttontd".$row["incid"]."\"><button id=\"perishedit".$row["incid"]."\" onclick=\"tool_fun(this.id);\">Edit</button></td>";
    			$str .= "</tr>";
    		}
    	}
    	$conn->close();
    	$str .= "</table>";
    	echo $str;
    }
    function perishable_items() {
    	$hotid = $_SESSION["hotelid"];
    	$i = 0;
    	require 'dbconnect.php';
    	$sql = "SELECT * FROM ingredients WHERE hotid=$hotid AND perishable='perish'";
    	$result = mysqli_query($conn,$sql);
    	$str = "<table class=\"listtable\">";
    	$str .= "<tr>";
    	$str .= "<th>Sr no</th>";
    	$str .= "<th>Items</th>";
    	$str .= "<th>Weight(Kg / L)</th>";
    	$str .= "<th>Damage Weight(Kg / L)</th>";
    	$str .= "<th>Unit</th>";
    	$str .= "<th>Cost</th>";
    	$str .= "<th>Date</th>";
    	$str .= "<th>Updae</th>";
    	$str .= "</tr>";
    	if(mysqli_num_rows($result) > 0) {
    		while ($row = mysqli_fetch_assoc($result)) {
    			$i++;
    			$str .= "<tr id=\"perishtr".$row["incid"]."\">";
    			$str .= "<td>".$i."</td>";
    			$str .= "<td id=\"itemtd".$row["incid"]."\">".$row["ingredient"]."</td>";
    			$str .= "<td id=\"weightconsttd".$row["incid"]."\">".$row["weight"]."</td>";
    			$str .= "<td id=\"weighttd".$row["incid"]."\">".$row["damageweight"]."</td>";
    			$str .= "<td id=\"unittd".$row["incid"]."\">".$row["incunit"]."</td>";
    			$str .= "<td id=\"costtd".$row["incid"]."\">".$row["cost"]."</td>";
    			$str .= "<td>".$row["incdate"]."</td>";
    			$str .= "<td id=\"buttontd".$row["incid"]."\"><button id=\"perishdamage".$row["incid"]."\" onclick=\"tool_fun(this.id);\">Damage</button></td>";
    			$str .= "</tr>";
    		}
    	}
    	$conn->close();
    	$str .= "</table>";
    	echo $str;
    }
    function perishable_add($item, $weight, $unit, $cost) {
    	$hotid = $_SESSION["hotelid"];
    	$perish_date = date("d-m-Y");
    	//--------Exists--------//
    	require 'dbconnect.php';
    	$sql = "SELECT * FROM perishable WHERE perishable='$item' AND perishhotid=$hotid";
    	$result = mysqli_query($conn,$sql);
    	if(mysqli_num_rows($result) > 0) {
    		$conn->close();
    		require 'dbconnect.php';
			$sql = "UPDATE perishable SET perishweight=perishweight+$weight, perishcost=perishcost+$cost, perishdate='$perish_date' WHERE perishable='$item' AND perishhotid=$hotid";
    		if (mysqli_query($conn, $sql)) {
                //echo "Record updated successfully";
                echo "done";
            } else {
                //echo "Error updating record: " . mysqli_error($conn);
            }
            $conn->close();
            exit();
    	}
    	$conn->close();
    	//--------Exists--------//

		require 'dbconnect.php';
		$sql = "INSERT INTO perishable (perishhotid, perishable, perishweight, perishunit, perishcost, perishdate) VALUES($hotid, '$item', $weight, '$unit', $cost, '$perish_date')";
        if (mysqli_query($conn, $sql)) {
            //echo "Record updated successfully";
            echo "done";
        } else {
            //echo "Error updating record: " . mysqli_error($conn);
        }
        $conn->close();
    }
?>