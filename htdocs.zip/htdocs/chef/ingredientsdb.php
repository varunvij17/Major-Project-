<?php
    session_start();
    date_default_timezone_set('Asia/Kolkata');
    if(isset($_POST["load"])){
    	listIngredients();
    }
    if(isset($_POST["srcincopt"])){
    	srcIncOpt($_POST["srcincopt"]);
    }
    if(isset($_POST["srcinc"])){
    	srcInc($_POST["srcinc"]);
    }
    if(isset($_POST["inc"]) && isset($_POST["wei"]) && isset($_POST["kg"]) && isset($_POST["perish"]) && isset($_POST["cos"]) && isset($_POST["warnpoint"]) && isset($_POST["limitpoint"])){
    	$wei = $_POST["wei"];
        $warnpoint = $_POST["warnpoint"];
        $limitpoint = $_POST["limitpoint"];
        $unit = "";
    	$ingdate = date("d-m-Y");
    	if(($_POST["kg"] == "g") || ($_POST["kg"] == "m")){
            //Grams to kilogram
    		$wei = $_POST["wei"] / 1000;
            $warnpoint = $_POST["warnpoint"] / 1000;
            $limitpoint = $_POST["limitpoint"] / 1000;
    	}
        if (($_POST["kg"] == "g") || ($_POST["kg"] == "k")) {
            $unit = "Kg";
        }
        if (($_POST["kg"] == "m") || ($_POST["kg"] == "l")) {
            $unit = "L";
        }
    	addInc($_POST["inc"],$wei,$_POST["cos"],$ingdate,$unit,$_POST["perish"],$warnpoint,$limitpoint);
    }
    if(isset($_POST["upinc"]) && isset($_POST["upwei"]) && isset($_POST["upcos"]) && isset($_POST["upingid"]) && isset($_POST["upperish"])){
    	$ingdate = date("d-m-Y");
    	upInc($_POST["upinc"],$_POST["upwei"],$_POST["upcos"],$ingdate,$_POST["upingid"],$_POST["upperish"]);
    }
    function upInc($inc,$wei,$cos,$ingdate,$ingid,$perish){
            require 'dbconnect.php';
            $sql = "UPDATE ingredients SET ingredient='$inc', weight=$wei, cost=$cos, incdate='$ingdate', perishable='$perish' WHERE incid=$ingid AND hotid=".$_SESSION["hotelid"];
            if (mysqli_query($conn, $sql)) {
                //echo "Record updated successfully";
            } else {
                //echo "Error updating record: " . mysqli_error($conn);
            }
            $conn->close();
        listIngredients();
    }
    function addInc($inc,$wei,$cos,$ingdate,$unit,$perish,$warnpoint,$limitpoint){
        require 'dbconnect.php';
        $sql = "SELECT * FROM ingredients WHERE hotid=".$_SESSION["hotelid"]." AND ingredient='".$inc."'";
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        if($rowcount > 0){
            mysqli_free_result($result);
            $sql = "UPDATE ingredients SET weight=weight+$wei, incunit='$unit', cost=cost+$cos, perishable='$perish', warningpoint=$warnpoint, limitpoint=$limitpoint WHERE ingredient='$inc'";
            if (mysqli_query($conn, $sql)) {
                //echo "Record updated successfully";
                listIngredients();
            } else {
                //echo "Error updating record: " . mysqli_error($conn);
            }
        }else{
            mysqli_free_result($result);
            $sql = "INSERT INTO ingredients (hotid,ingredient,weight,incunit,cost,incdate,perishable,warningpoint,limitpoint) VALUES(".$_SESSION["hotelid"].",'$inc',$wei,'$unit',$cos,'$ingdate','$perish',$warnpoint,$limitpoint)";
            if (mysqli_query($conn, $sql)) {
                //echo "Record updated successfully";
                listIngredients();
            } else {
                //echo "Error updating record: " . mysqli_error($conn);
            }
        }
        $conn->close();
    }
    function srcInc($srcinc){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM ingredients WHERE hotid=".$_SESSION["hotelid"]." AND ingredient LIKE '%".$srcinc."%'";
        $result = mysqli_query($conn,$sql);
        echo "<table class='listtable'>";
        echo "<tr><th>Sr.No</th><th>Ingredients</th><th>Weight</th><th>Cost</th><th>Date</th><th>Update</th></tr>";
        if(mysqli_num_rows($result) > 0){
        	$i = 1;
            while ($row = mysqli_fetch_assoc($result)){
            	echo "<tr><td>".$i."</td><td id='ingredients".$row["incid"]."'>".$row["ingredient"]."</td><td id='weight".$row["incid"]."'>".$row["weight"]."</td><td id='cost".$row["incid"]."'>".$row["cost"]."</td><td>".$row["incdate"]."</td><td id='edit".$row["incid"]."'><a name='edit".$row["incid"]."' onclick='ingupdate(this.name)'>Edit</a></td></tr>";
            	$i++;
            }
        }
        echo "</table>";
        $conn->close();
    }
    function srcIncOpt($srcinc){
    	require 'dbconnect.php';
        $sql = "SELECT DISTINCT ingredient FROM ingredients WHERE ingredient LIKE '%".$srcinc."%'";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	echo "<option value='".$row["ingredient"]."'>";
            }
        }
        $conn->close();
    }
    function listIngredients(){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM ingredients WHERE hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        echo "<table class='listtable'>";
        echo "<tr><th>Sr.No</th><th>Ingredients</th><th>Weight(Kg)</th><th>Cost</th><th>Perishable</th><th>Date</th><th>Update</th></tr>";
        // echo "<tr><th>Sr.No</th><th>Ingredients</th><th>Weight(Kg)</th><th>Cost</th><th>Perishable</th><th colspan=\"3\">Alert</th><th>Date</th><th>Update</th></tr>";
        if(mysqli_num_rows($result) > 0){
        	$i = 1;
            while ($row = mysqli_fetch_assoc($result)){
            	// echo "<tr id='trIng".$row["incid"]."'><td>".$i."</td><td id='ingredients".$row["incid"]."'>".$row["ingredient"]."</td><td id='weight".$row["incid"]."'>".$row["weight"]."</td><td id='cost".$row["incid"]."'>".$row["cost"]."</td><td id='perishable".$row["incid"]."'>".$row["perishable"]."</td><td id='warnpoint".$row["incid"]."'>".$row["warningpoint"]."</td><td id='limitpoint".$row["incid"]."'>".$row["limitpoint"]."</td><td id='alertpointedit".$row["incid"]."'><button name='alertedit".$row["incid"]."' onclick='ingupdate(this.name)'>Edit</button></td><td>".$row["incdate"]."</td><td id='edit".$row["incid"]."'><button name='edit".$row["incid"]."' onclick='ingupdate(this.name)'>Edit</button></td></tr>";
                echo "<tr id='trIng".$row["incid"]."'><td>".$i."</td><td id='ingredients".$row["incid"]."'>".$row["ingredient"]."</td><td id='weight".$row["incid"]."'>".$row["weight"]."</td><td id='cost".$row["incid"]."'>".$row["cost"]."</td><td id='perishable".$row["incid"]."'>".$row["perishable"]."</td><td>".$row["incdate"]."</td><td id='edit".$row["incid"]."'><button name='edit".$row["incid"]."' onclick='ingupdate(this.name)'>Edit</button></td></tr>";
            	$i++;
            }
        }
        echo "</table>";
        $conn->close();
    }
?>