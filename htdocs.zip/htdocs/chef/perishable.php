<title>Perishable</title>
<!-- <table>
	<tr>
		<th><input type="text" id="perishableiteminput" placeholder="Item" oninput="src_perish(this.id);"></th>
		<th><input type="text" id="perishableweightinput" placeholder="Weight"></th>
		<th><select id="unit">
				<option value="sel">---SELECT---</option>
				<option value="g">Gram</option>
				<option value="k">Kilogram</option>
				<option value="m">Milliliter</option>
				<option value="l">Liter</option>
			</select></th>
		<th><input type="number" id="perishablecostinput" placeholder="Cost"><button id="perishableaddbutton" onclick="perishable_fun(this.id);">Add</button></th>
	</tr>
</table> -->
<div id="load"></div>
<script type="text/javascript">
	$("#load").load("chef/perishabledb.php",{
		load : "load"
	});
	// function perishable_fun(bm) {
	// 	if (bm == "perishableaddbutton") {
	// 		let perishableiteminput = $("#perishableiteminput").val();
	// 		let perishableweightinput = $("#perishableweightinput").val();
	// 		let unit = $("#unit").val();
	// 		let perishablecostinput = $("#perishablecostinput").val();
	// 		let warnstr = "";
	// 		if (perishableiteminput.length <= 0) {
	// 			warnstr += "Item Empty !<br>";
	// 		}
	// 		if (perishableweightinput.length <= 0) {
	// 			warnstr += "Weight Empty !<br>";
	// 		}
	// 		if (unit == "sel") {
	// 			warnstr += "Select weight unit !<br>";
	// 		}
	// 		if (perishablecostinput.length <= 0) {
	// 			warnstr += "Cost Empty !<br>";
	// 		}
	// 		if (warnstr != "") {
	// 			warning_disp(warnstr);
	// 		} else {
	// 			$.post("chef/perishabledb.php",{
	// 				item : perishableiteminput,
	// 				weight : perishableweightinput,
	// 				unit : unit,
	// 				cost : perishablecostinput
	// 			},function(result) {
	// 				if (result == "done") {
	// 					warning_disp("Item Success !");
	// 					$("#load").load("chef/perishabledb.php",{
	// 						load : "load"
	// 					});
	// 				}
	// 			});
	// 		}
	// 	}
	// }
	function tool_fun(bm) {
		let bmname = bm.match(/[a-zA-Z]+/g);
		let bmid = bm.match(/(\d+)/);
		if (bmname[0] == "perishdamage") {
			let tag_build = "";
			let tag = "#perishtr"+bmid[0];
			old_tag[Number(bmid[0])] = $(tag).html();
			tag = "#itemtd"+bmid[0];
			tag = "#weighttd"+bmid[0];
			let weighttd = $(tag).text();
			tag_build = "<input type=\"text\" id=\"perishableweightinput"+bmid[0]+"\" placeholder=\"Weight\" value=\""+weighttd+"\">";
			$(tag).html(tag_build);
			tag = "#buttontd"+bmid[0];
			tag_build = "<button id=\"perishableupdatebutton"+bmid[0]+"\" onclick=\"tool_fun(this.id);\">Update</button><button id=\"perishablecancelbutton"+bmid[0]+"\" onclick=\"tool_fun(this.id);\">Cancel</button>";
			$(tag).html(tag_build);
		}
		if (bmname[0] == "perishablecancelbutton") {
			let tag = "#perishtr"+bmid[0];
			$(tag).html(old_tag[Number(bmid[0])]);
		}
		if (bmname[0] == "perishableupdatebutton") {
			let tag = "#perishableweightinput"+bmid[0];
			let perishableweightinput = Number($(tag).val());
			let currentweight_bool = true;
			tag = "#weightconsttd"+bmid[0];
			if ((Number($(tag).text()) < 0) || (Number($(tag).text()) < perishableweightinput)) {
				warning_disp("Cannot Damage Below Current Weight !");
				currentweight_bool = false;
			}
			if (currentweight_bool) {
				lettagcosttd = "#costtd"+bmid[0];
				let damagecost = (Number($(lettagcosttd).text()) / Number($(tag).text())) * perishableweightinput;
				let reduce_weight = Number($(tag).text()) - perishableweightinput;
				if (reduce_weight < 0) {reduce_weight=0;}
				let reduce_cost = Number($(lettagcosttd).text()) - damagecost;
				if (reduce_cost < 0) {reduce_cost = 0;}
				let warnstr = "";
				if (perishableweightinput.length <= 0) {
					warnstr += "Weight Empty !<br>";
				}
				if (warnstr != "") {
					warning_disp(warnstr);
				} else {
					$.post("chef/perishabledb.php",{
						itemid_update : bmid[0],
						weight_update : perishableweightinput,
						cost_update : damagecost,
						reduce_weight : reduce_weight,
						reduce_cost : reduce_cost
					},function(result) {
						if (result == "done") {
							$("#load").load("chef/perishabledb.php",{
								load : "load"
							});
						}
					});
				}
			}
		}
	}
	function src_perish(bm) {
		$("#load").load("chef/perishabledb.php",{
			srcitem : $("#perishableiteminput").val()
		});
	}
</script>