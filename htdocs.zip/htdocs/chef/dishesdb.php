<?php
    session_start();
    if(isset($_POST["load"])){
    	listDishes();
    }
    if(isset($_POST["delete_dis"])){
        DeleteDishes($_POST["delete_dis"]);
    }
    if(isset($_POST["uprice"]) && isset($_POST["updisid"])){
    	uprice($_POST["uprice"],$_POST["updisid"]);
    }
    if(isset($_POST["remprice"]) && isset($_POST["remdisid"]) && isset($_POST["remingr"])){
    	$ingr = explode("(*-)", $_POST["remingr"]);
    	upricerem($_POST["remprice"],$_POST["remdisid"],$ingr);
    }
    if(isset($_POST["upaddprice"]) && isset($_POST["upadddisid"]) && isset($_POST["upaddingr"]) && isset($_POST["upaddgram"])){
        $ingr = explode("(*-)", $_POST["upaddingr"]);
        $grams = explode("(*-)", $_POST["upaddgram"]);
        upadddishIngr($_POST["upaddprice"],$_POST["upadddisid"],$ingr,$grams);
    }
    if(isset($_POST["disid"])){
    	EditDis($_POST["disid"]);
    }
    if(isset($_POST["ingrs"])){
    	getIngrId($_POST["ingrs"]);
    }
    if(isset($_POST["srcingropt"])){
    	srcIngrOpt($_POST["srcingropt"]);
    }
    if(isset($_POST["srcdisopt"])){
    	srcDisOpt($_POST["srcdisopt"]);
    }
    if(isset($_POST["srcdis"])){
    	srcDis($_POST["srcdis"]);
    }
    if(isset($_POST["dis"]) && isset($_POST["inc"]) && isset($_POST["wei"]) && isset($_POST["cos"])){
    	$inc = explode("(*-)", $_POST["inc"]);
    	$wei = explode("(*-)", $_POST["wei"]);
    	addDishes($_POST["dis"],$inc,$wei,$_POST["cos"]);
    }
    function DeleteDishes($disid){
        require 'dbconnect.php';
        //-----------------------------------Delete Dish-----------------------------------//
        $sql = "DELETE FROM dishes WHERE disid=".$disid." AND hotid=".$_SESSION["hotelid"];
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        //-----------------------------------Delete Dish Incredients-----------------------------------//

        //-----------------------------------Delete Dish-----------------------------------//
        $sql = "DELETE FROM dishing WHERE dishid=".$disid." AND hotid=".$_SESSION["hotelid"];
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        //-----------------------------------Delete Dish Incredients-----------------------------------//

        $conn->close();
    }
    function upricerem($uprice,$disid,$ingr){
    	require 'dbconnect.php';
        $i = 0;
        while ($i < count($ingr)) {
            $sql = "DELETE FROM dishing WHERE (dishid=".$disid." AND hotid=".$_SESSION["hotelid"].") AND ingrid=".$ingr[$i];
            if (mysqli_query($conn, $sql)) {
                //echo "New record created successfully";
            } else {
                //echo "Error: " . $sql . "" . mysqli_error($conn);
            }
            $i++;
        }
        $conn->close();
    }
    function upadddishIngr($uprice,$disid,$ingr,$grams){
        require 'dbconnect.php';
        $i = 0;
        while ($i < count($ingr)) {
            $sql = "SELECT * FROM dishing WHERE (dishid=".$disid." AND hotid=".$_SESSION["hotelid"].") AND ingrid=".$ingr[$i];
            $rowcount = mysqli_num_rows(mysqli_query($conn,$sql));
            if ($rowcount <= 0) {
                $sql = "INSERT INTO dishing (hotid,dishid,ingrid,gram) VALUES(".$_SESSION["hotelid"].",".$disid.",".$ingr[$i].",".$grams[$i].")";
                if (mysqli_query($conn, $sql)) {
                    //echo "Record updated successfully";
                    //listIngredients();
                } else {
                    //echo "Error updating record: " . mysqli_error($conn);
                }
            }else{
                $sql = "UPDATE dishing SET gram=".$grams[$i]." WHERE (dishid=".$disid." AND hotid=".$_SESSION["hotelid"].") AND ingrid=".$ingr[$i];
                if (mysqli_query($conn, $sql)) {
                    //echo "New record created successfully";
                } else {
                    //echo "Error: " . $sql . "" . mysqli_error($conn);
                }
            }
            $sql = "UPDATE dishes SET price=".$uprice." WHERE disid=".$disid." AND hotid=".$_SESSION["hotelid"];
            if (mysqli_query($conn, $sql)) {
                //echo "New record created successfully";
            } else {
                //echo "Error: " . $sql . "" . mysqli_error($conn);
            }
            $i++;
        }
        $conn->close();
    }
    function uprice($uprice,$disid){
    	require 'dbconnect.php';
        $sql = "UPDATE dishes SET price=".$uprice." WHERE disid=".$disid." AND hotid=".$_SESSION["hotelid"];
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
            listStaff1($hotelid);
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $conn->close();
    }
    function EditDis($disid){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishes WHERE disid=".$disid." AND hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	echo "<td>Editing...</td><td id='dishes".$row["disid"]."'>".$row["dish"]."</td><td id='ingredient".$row["disid"]."'>".ingritems($row["disid"])."</td><td id='gram".$row["disid"]."'>".ingritemsgram($row["disid"])."</td><th id='delingr".$row["disid"]."'>".delingr($row["disid"])."</th><td id='price".$row["disid"]."'><input id='prices".$row["disid"]."' value='".$row["price"]."' /></td><td id='edit".$row["disid"]."'><a name='update".$row["disid"]."' onclick='dishupdate(this.name)'>Update</a><a name='cancel".$row["disid"]."' onclick='dishupdate(this.name)'>Cancel</a></td>";
            }
        }
        $conn->close();
    }
    function listDishes(){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishes WHERE hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        echo "<table class='listtable'>";
        echo "<tr><th>Sr.No</th><th>Dishes</th><th>Ingredients</th><th>Gram</th><th></th><th>Price</th><th>Tool</th></tr>";
        if(mysqli_num_rows($result) > 0){
        	$i = 1;
            while ($row = mysqli_fetch_assoc($result)){
            	echo "<tr id='item".$row["disid"]."'><td>".$i."</td><td id='dishes".$row["disid"]."'>".$row["dish"]."</td><td id='ingredient".$row["disid"]."'>".ingredients($row["disid"])."</td><td id='gram".$row["disid"]."' colspan='2'>".ingredientsGram($row["disid"])."</td><td id='price".$row["disid"]."'>".$row["price"]."</td><td id='edit".$row["disid"]."'><button name='edit".$row["disid"]."' onclick='dishupdate(this.name)'>Edit</button>&nbsp;&nbsp;&nbsp;<button name='delete".$row["disid"]."' onclick='dishupdate(this.name)'>Delete</button></td></tr>";
            	$i++;
            }
        }
        echo "</table>";
        $conn->close();
    }
    function srcDis($srcdis){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishes WHERE dish LIKE '%".$srcdis."%' AND hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        echo "<table class='listtable'>";
        echo "<tr><th>Sr.No</th><th>Dishes</th><th>Ingredients</th><th>Gram</th><th></th><th>Price</th><th>Tool</th></tr>";
        if(mysqli_num_rows($result) > 0){
        	$i = 1;
            while ($row = mysqli_fetch_assoc($result)){
            	echo "<tr id='item".$row["disid"]."'><td>".$i."</td><td id='dishes".$row["disid"]."'>".$row["dish"]."</td><td id='ingredient".$row["disid"]."'>".ingredients($row["disid"])."</td><td id='gram".$row["disid"]."' colspan='2'>".ingredientsGram($row["disid"])."</td><td id='price".$row["disid"]."'>".$row["price"]."</td><td id='edit".$row["disid"]."'><a name='edit".$row["disid"]."' onclick='dishupdate(this.name)'>Edit</a><a name='delete".$row["disid"]."' onclick='dishupdate(this.name)'>Delete</a></td></tr>";
            	$i++;
            }
        }
        echo "</table>";
        $conn->close();
    }
    function ingritems($disid){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishing a,ingredients b WHERE a.dishid=".$disid." AND b.incid=a.ingrid";
        $result = mysqli_query($conn,$sql);
        $ingr = "";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	$ingr .= "<span id='".$disid."ingr".$row["ingrid"]."'>".$row["ingredient"]."</span><br>";
            }
        }
        $conn->close();
        return $ingr;
    }
    function ingritemsgram($disid){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishing a,ingredients b WHERE a.dishid=".$disid." AND b.incid=a.ingrid";
        $result = mysqli_query($conn,$sql);
        $ingr = "";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	$ingr .= "<span id='".$disid."gram".$row["ingrid"]."'>".$row["gram"]."</span><br>";
            }
        }
        $conn->close();
        return $ingr;
    }
    function delingr($disid){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishing a,ingredients b WHERE a.dishid=".$disid." AND b.incid=a.ingrid";
        $result = mysqli_query($conn,$sql);
        $ingr = "";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	$ingr .= "<a name='".$disid."delingr".$row["ingrid"]."' onclick='dishupdate(this.name)'>Delete</a><br>";
            }
        }
        $conn->close();
        return $ingr;
    }
    function ingredients($disid){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishing a,ingredients b WHERE a.dishid=".$disid." AND b.incid=a.ingrid";
        $result = mysqli_query($conn,$sql);
        $ingr = "";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	$ingr .= $row["ingredient"]."<br>";
            }
        }
        $conn->close();
        return $ingr;
    }
    function ingredientsGram($disid){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishing WHERE dishid=".$disid;
        $result = mysqli_query($conn,$sql);
        $ingr = "";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	$ingr .= $row["gram"]."<br>";
            }
        }
        $conn->close();
        return $ingr;
    }
    function srcIngrOpt($srcingr){
        $htsid = $_SESSION["hotelid"];
    	require 'dbconnect.php';
        $sql = "SELECT DISTINCT * FROM ingredients WHERE ingredient LIKE '%".$srcingr."%' AND hotid=$htsid";
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        $str = "";
        $tr = true;
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	$str .= "<option value='".$row["ingredient"]."'>";
            }
            $tr = false;
        }
        $conn->close();
        require 'dbconnect.php';
        $sql = "SELECT DISTINCT * FROM perishable WHERE perishable LIKE '%".$srcingr."%' AND perishhotid=$htsid";
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                $str .= "<option value='".$row["perishable"]."'>";
            }
            $tr = false;
        }
        $conn->close();
        if ($tr) {
        	echo "<option value='Invalid'>Invalid</option>";
            exit();
        }
        echo $str;
    }
    function getIngrId($srcingr){
        	require 'dbconnect.php';
            $sql = "SELECT incid FROM ingredients WHERE ingredient='".$srcingr."' AND hotid=".$_SESSION["hotelid"];
            $result = mysqli_query($conn,$sql);
            $rowcount = mysqli_num_rows($result);
            if($rowcount > 0){
                $row = mysqli_fetch_assoc($result);
                echo $row["incid"];
            }else{
                echo "NotExist";
            }
            $conn->close();
    }
    function srcDisOpt($srcdis){
    	require 'dbconnect.php';
        $sql = "SELECT dish FROM dishes WHERE dish LIKE '%".$srcdis."%'";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	echo "<option value='".$row["dish"]."'>".$row["dish"]."</option>";
            }
        }
        $conn->close();
    }
    function addDishes($dis,$inc,$wei,$cos){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishes WHERE dish='".$dis."' AND hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        if($rowcount > 0){
            echo "Exist";
        }else{
            $sql = "INSERT INTO dishes (hotid,dish,price) VALUES(".$_SESSION["hotelid"].",'".$dis."',".$cos.")";
            if (mysqli_query($conn, $sql)) {
                //echo "Record updated successfully";
                //listIngredients();
            } else {
                //echo "Error updating record: " . mysqli_error($conn);
            }
            //Get Dish ID
            $sql = "SELECT disid FROM dishes WHERE dish='".$dis."' AND hotid=".$_SESSION["hotelid"];
            $result = mysqli_query($conn,$sql);
            $rowcount = mysqli_num_rows($result);
            if($rowcount > 0){
                $row = mysqli_fetch_assoc($result);
                $i = 0;
                while ($i < count($inc)) {
                	$sql = "INSERT INTO dishing (hotid,dishid,ingrid,gram) VALUES(".$_SESSION["hotelid"].",".$row["disid"].",".$inc[$i].",".$wei[$i].")";
                	$result = mysqli_query($conn,$sql);
                	$i++;
                }
            }
            echo "Done";
        }
        $conn->close();
    }
?>