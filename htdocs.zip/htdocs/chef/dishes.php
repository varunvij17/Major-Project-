<!DOCTYPE html>
<html>
<head>
	<title>Dishes</title>
</head>
<body>
	<table>
		<tr>
			<td><input type="text" name="dishname" placeholder="Dish" list="srcdish" oninput="srcdish(this.name)" />
				<datalist id="srcdish"></datalist>
			</td>
			<td><input type="text" name="ingr" placeholder="Ingredient"  list="srcingr" oninput="srcdish(this.name)" onkeypress="return isNumberKey(event)" />
				<datalist id="srcingr"></datalist>
			</td>
			<td><input type="text" name="gram" onkeypress="return isNumberKey(event)" placeholder="Gram / Milliliter" /></td>
			<td><input type="text" name="cost" placeholder="Cost" /></td>
			<td><a name="addDish" class="button" onclick="addDish(this.name)">Add / Search</a></td>
		</tr>
		<tr>
			<td id="dishwar"></td>
			<td id="ingwar"></td>
			<td id="gramwar"></td>
			<td id="costwar"></td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<td id="dishIngr"></td>
			<td id="ingGram"></td>
			<td></td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<th colspan="2"><a name="addnxt" onclick="addnxt(this.name)">Ingredient +</a></th>
			<td></td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<td id="ingrlist"></td>
			<td id="gramlist"></td>
			<td></td>
			<td></td>
		</tr>
	</table>
	<p id="load"></p>
</body>
<script type="text/javascript">
	$("#load").load("chef/dishesdb.php",{
		load : "load"
	});
	//-------------Add Dish-------------------//
	var ingrlist = [], gramlist = [], ingrid = [];
	//-------------Add Dish-------------------//

	//-------------Upate Dish-----------------//
	var removeIngrId = [], removeDisId = [], addDishIdList = [], addIngrNameList = [], addIngrIdList = [], addGramList = [];
	//-------------Upate Dish-----------------//

	function dishupdate(bm){
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/g);
		if (bmname[0] == "delete") {
			$.post("chef/dishesdb.php",{
				delete_dis : bmid[0]
			});
			location.reload();
		}
		if(bmname[0] == "edit"){
			var trid = "#item"+bmid[0];
			$(trid).load("chef/dishesdb.php",{
				disid : bmid[0]
			});
			var addtr = "#addtr"+bmid[0];
			if(!($(addtr).length)){
				var str = "<tr id='addtr"+bmid[0]+"'><td></td><td></td><th colspan='3'><a name='addingr"+bmid[0]+"' onclick='dishupdate(this.name)'>Ingredient +</a></th><td></td><td></td></tr>";
				$(trid).after(str);
			}
		}
		if (bmname[0] == "cancel") {
			$("#load").load("chef/dishesdb.php",{
				load : "load"
			});
		}
		if (bmname[0] == "delingr") {
			let tr_bool = true;
			let tag = "#gram"+bmid[0]+" span";
			if ($(tag).length > 0) {
				if ($(tag).length == 1) {
					warning_disp("Need atleast one ingredients !");
					tr_bool = false;
				}
			}
			if (tr_bool) {
				var ArrLength = removeIngrId.length;
				removeIngrId[ArrLength] = bmid[1];
				removeDisId[ArrLength] = bmid[0];
				var ingrSpan = "#"+bmid[0]+"ingr"+bmid[1];
				var gramSpan = "#"+bmid[0]+"gram"+bmid[1];
				var delingr = bmid[0]+"delingr"+bmid[1];
				$(ingrSpan).next('br').remove();
				$(ingrSpan).remove();
				$(gramSpan).next('br').remove();
				$(gramSpan).remove();
				$("a[name~='"+delingr+"']").next('br').remove();
				$("a[name~='"+delingr+"']").remove();
			}
			
		}
		if (bmname[0] == "addelingr") {
			let tr_bool = true;
			let tag = "#gram"+bmid[0]+" span";
			if ($(tag).length > 0) {
				if ($(tag).length == 1) {
					warning_disp("Need atleast one ingredients !");
					tr_bool = false;
				}
			}
			if (tr_bool) {
				var ingrSpan = "#"+bmid[0]+"ingr"+bmid[1];
				var gramSpan = "#"+bmid[0]+"gram"+bmid[1];
				var delingr = bmid[0]+"addelingr"+bmid[1];
				$(ingrSpan).next('br').remove();
				$(ingrSpan).remove();
				$(gramSpan).next('br').remove();
				$(gramSpan).remove();
				$("a[name~='"+delingr+"']").next('br').remove();
				$("a[name~='"+delingr+"']").remove();
				var j = 0, ilength = addIngrIdList.length;
				console.log(ilength);
				while(j < ilength){
					if((addDishIdList[j] == bmid[0]) && (addIngrIdList[j] == bmid[1])){
						while(j < (ilength - 1)){
							addDishIdList[j] = addDishIdList[j+1];
							addIngrNameList[j] = addIngrNameList[j+1];
							addIngrIdList[j] = addIngrIdList[j+1];
							addGramList[j] = addGramList[j+1];
							j++;
						}
					}
					j++;
				}
				addDishIdList.length = ilength - 1;
				addIngrNameList.length = ilength - 1;
				addIngrIdList.length = ilength - 1;
				addGramList.length = ilength - 1;
				console.log(addIngrIdList.length);
			}
		}
		if (bmname[0] == "addingr") {
			var trid = "#addtr"+bmid[0];
			var str = "<td></td><td></td><td><input name='addDishIngr"+bmid[0]+"' placeholder='Ingredient'  list='srcdishingr'  oninput='srcdishes(this.name)' /><datalist id='srcdishingr'></datalist></td><td><input name='addDishGram' placeholder='Gram' /></td><td><button name='submitDishIngr"+bmid[0]+"' onclick='dishupdate(this.name)'>Add</button><button name='cancelDishIngr"+bmid[0]+"' onclick='dishupdate(this.name)'>Cancel</button></td><td></td><td></td>";
			$(trid).html(str);
		}
		if (bmname[0] == "cancelDishIngr") {
			var trid = "#addtr"+bmid[0];
			var str = "<td></td><td></td><th colspan='3'><a name='addingr"+bmid[0]+"' onclick='dishupdate(this.name)'>Ingredient +</a></th><td></td><td></td>";
			$(trid).html(str);
		}
		if (bmname[0] == "submitDishIngr") {
			var ingrinput = false, graminput = false;
			if ($("input[name~='addDishIngr"+bmid[0]+"']").val() != "") {
				ingrinput = true;
			}
			if (($("input[name~='addDishGram']").val() != "") && ($("input[name~='addDishGram']").val() > 0)) {
				graminput = true;
			}
			if (ingrinput && graminput) {
				$.ajax({
					async:false,
				    url: "chef/dishesdb.php",
				    type: "POST",
				    data: {ingrs : $("input[name~='addDishIngr"+bmid[0]+"']").val()},
				    success: function (result) {
				    	if (result != "NotExist") {
				    		ingrinput = false;
				    		var ilength = addIngrIdList.length, j = 0, arrayPosition = -1;
				    		if (ilength == 0) {
				    			ingrinput = true;
				    		}else{
				    			while(j < ilength){
				    				if((addIngrIdList[j] == JSON.parse(result)) && (addDishIdList[j] == bmid[0])){
				    					arrayPosition = j;
				    				}
				    				j++;
				    			}
				    			if (arrayPosition == -1) {
				    				ingrinput = true;
				    			}
				    		}
				    		if (ingrinput) {
				    			ilength = addIngrIdList.length;
				    			addIngrIdList[ilength] = JSON.parse(result);
				    			addDishIdList[ilength] = bmid[0];
				    			addIngrNameList[ilength] = $("input[name~='addDishIngr"+bmid[0]+"']").val();
				    			addGramList[ilength] = $("input[name~='addDishGram']").val();
				    			var tdAppend = "#ingredient"+bmid[0];
				    			var strs = "<span id='"+addDishIdList[ilength]+"ingr"+addIngrIdList[ilength]+"'>"+addIngrNameList[ilength]+"</span><br>";
				    			$(tdAppend).append(strs);
				    			tdAppend = "#gram"+bmid[0];
				    			strs = "<span id='"+addDishIdList[ilength]+"gram"+addIngrIdList[ilength]+"'>"+addGramList[ilength]+"</span><br>";
				    			$(tdAppend).append(strs);
				    			tdAppend = "#delingr"+bmid[0];
				    			strs = "<a name='"+addDishIdList[ilength]+"addelingr"+addIngrIdList[ilength]+"' onclick='dishupdate(this.name)'>Delete -</a><br>";
				    			$(tdAppend).append(strs);
				    		}
				    	}
				    },
				    error: function(jqXHR, textStatus, errorThrown) {
				        console.log(textStatus, errorThrown);
				    }
				});
			}
		}
		if (bmname[0] == "update") {
			//------------  Update Price
			if ((removeIngrId.length == 0) && (addIngrIdList.length == 0)) {
				var price = "#prices"+bmid[0];
				console.log(price);
				if ($(price).val() != "") {
					$.ajax({
						async:false,
						url: "chef/dishesdb.php",
						type: "POST",
						data: {uprice : $(price).val(), updisid : bmid[0]},
						success: function (result) {
							location.reload();
						}
					});
				}
			}
			//--------------  Remove Ingredients (Update)
			if ((removeIngrId.length > 0) && (addIngrIdList.length == 0)) {
				var price = "#prices"+bmid[0], j = 0, ilength = removeIngrId.length, str = "", counts = 0, reach = 0;
				while(j < ilength){
					if(removeDisId[j] == Number(bmid[0])){
						counts++;
					}
					j++;
				}
				j = 0;
				while(j < ilength){
					if(removeDisId[j] == Number(bmid[0])){
						reach++;
						if (reach < counts) {
							str += removeIngrId[j]+"(*-)";
						}else{
							str += removeIngrId[j];
						}
					}
					j++;
				}
				if ($(price).val() != "") {
					$.ajax({
						async:false,
						url: "chef/dishesdb.php",
						type: "POST",
						data: {remprice : $(price).val(), remdisid : bmid[0], remingr : str},
						success: function (result) {
							location.reload();
						}
					});
				}
			}
			//---------  Add Ingredients (Update)
			if ((removeIngrId.length == 0) && (addIngrIdList.length > 0)) {
				var price = "#prices"+bmid[0], j = 0, ilength = addIngrIdList.length, str = "", counts = 0, reach = 0;
				var strgram = "";
				while(j < ilength){
					if(addDishIdList[j] == Number(bmid[0])){
						counts++;
					}
					j++;
				}
				j = 0;
				while(j < ilength){
					if(addDishIdList[j] == Number(bmid[0])){
						reach++;
						if (reach < counts) {
							str += addIngrIdList[j]+"(*-)";
							strgram += addGramList[j]+"(*-)";
						}else{
							str += addIngrIdList[j];
							strgram += addGramList[j];
						}
					}
					j++;
				}
				if ($(price).val() != "") {
					$.ajax({
						async:false,
						url: "chef/dishesdb.php",
						type: "POST",
						data: {upaddprice : $(price).val(), upadddisid : bmid[0], upaddingr : str, upaddgram : strgram},
						success: function (result) {
							location.reload();
						}
					});
				}
			}
			//---------  Add and Remove Ingredients (Update)
			//removeIngrId = [], removeDisId = [], addDishIdList = [], addIngrNameList = [], addIngrIdList = [], addGramList = []
			if ((removeIngrId.length > 0) && (addIngrIdList.length > 0)) {
				var price = "#prices"+bmid[0], j = 0, ilength = removeIngrId.length, str = "", counts = 0, reach = 0;
				while(j < ilength){
					if(removeDisId[j] == Number(bmid[0])){
						counts++;
					}
					j++;
				}
				j = 0;
				while(j < ilength){
					if(removeDisId[j] == Number(bmid[0])){
						reach++;
						if (reach < counts) {
							str += removeIngrId[j]+"(*-)";
						}else{
							str += removeIngrId[j];
						}
					}
					j++;
				}
				if ($(price).val() != "") {
					$.ajax({
						async:false,
						url: "chef/dishesdb.php",
						type: "POST",
						data: {remprice : $(price).val(), remdisid : bmid[0], remingr : str},
						success: function (result) {
							//location.reload();
						}
					});
				}
				price = "#prices"+bmid[0]; j = 0; ilength = addIngrIdList.length; str = ""; counts = 0; reach = 0;
				var strgram = "";
				while(j < ilength){
					if(addDishIdList[j] == Number(bmid[0])){
						counts++;
					}
					j++;
				}
				j = 0;
				while(j < ilength){
					if(addDishIdList[j] == Number(bmid[0])){
						reach++;
						if (reach < counts) {
							str += addIngrIdList[j]+"(*-)";
							strgram += addGramList[j]+"(*-)";
						}else{
							str += addIngrIdList[j];
							strgram += addGramList[j];
						}
					}
					j++;
				}
				if ($(price).val() != "") {
					$.ajax({
						async:false,
						url: "chef/dishesdb.php",
						type: "POST",
						data: {upaddprice : $(price).val(), upadddisid : bmid[0], upaddingr : str, upaddgram : strgram},
						success: function (result) {
							location.reload();
						}
					});
				}
			}
		}
	}
	function isNumberKey(evt){
        var charsm = String.fromCharCode(evt.which || evt.keyCode);
        if((charsm == "*") || (charsm == "-")){
            return false;
        }
        return true;
    }
	function addnxt(bm){
		if(bm == "addnxt"){
			var inc = false, wei = false, inid = false;
			var ingrI = ingrlist.length;
			if($("input[name~='ingr']").val() != ""){
				$("#ingwar").html("");
				inc = true;
			}
			if(($("input[name~='gram']").val() != "") && ($("input[name~='gram']").val() > 0)){
				$("#gramwar").html("");
				wei = true;
			}
			if (inc && wei){
				$.ajax({
					async:false,
				    url: "chef/dishesdb.php",
				    type: "POST",
				    data: {ingrs : $("input[name~='ingr']").val()},
				    success: function (result) {
				    	if (result != "NotExist") {
				    		ingrid[ingrI] = JSON.parse(result);
				    		$("#ingwar").html("");
				    		inid = true;
				    	}else{
				    	   	$("#ingwar").html("This Ingredient is not Exist");
				    	   	inid = false;
				    }
				    },
				    error: function(jqXHR, textStatus, errorThrown) {
				        console.log(textStatus, errorThrown);
				    }
				});
			}
			if (inc && wei && inid) {
				ingrlist[ingrI] = $("input[name~='ingr']").val();
				gramlist[ingrI] = $("input[name~='gram']").val();
				$("input[name~='ingr']").val("");
				$("input[name~='gram']").val("");
				var i = 0, j = 0, strI = "", strG = "";
				while(i < ingrlist.length){
					j++;
					strI += "<tr><td>"+j+"</td><td>"+ingrlist[i]+"</td></tr>";
					strG += "<tr><td>"+gramlist[i]+"</td><th><a name='ingremove"+i+"' onclick='removeingr(this.name)'>-</a></th></tr>";
				    i++;
				}
				$("#ingrlist").html(strI);
				$("#gramlist").html(strG);
			}
			if(!inc){
				$("#ingwar").html("Require");
			}
			if(!wei){
				$("#gramwar").html("Require");
			}
		}
	}
	function removeingr(bm){
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/);
		if (bmname[0] == "ingremove") {
			var i = Number(bmid[0]), j = 0, strI = "", strG = "";
			while(i < (ingrlist.length - 1)){
				ingrlist[i] = ingrlist[i+1];
				gramlist[i] = gramlist[i+1];
				ingrid[i] = ingrid[i+1];
				i++;
			}
			i = 0;
			ingrlist.length = ingrlist.length - 1;
			gramlist.length = gramlist.length - 1;
			ingrid.length = ingrid.length - 1;
			while(i < ingrlist.length){
				j++;
				strI += "<tr><td>"+j+"</td><td>"+ingrlist[i]+"</td></tr>";
				strG += "<tr><td>"+gramlist[i]+"</td><th><a name='ingremove"+i+"' onclick='removeingr(this.name)'>-</a></th></tr>";
				i++;
			}
			$("#ingrlist").html(strI);
			$("#gramlist").html(strG);
		}
	}
	function srcdishes(bm) {
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/g);
		if(bmname[0] == "addDishIngr"){
			$("#srcdishingr").load("chef/dishesdb.php",{
				srcingropt : $("input[name~='"+bm+"']").val()
			});
		}
	}
	function srcdish(bm) {
		if(bm == "dishname"){
			$("#srcdish").load("chef/dishesdb.php",{
				srcdisopt : $("input[name~='"+bm+"']").val()
			});
			$("#load").load("chef/dishesdb.php",{
				srcdis : $("input[name~='"+bm+"']").val()
			});
		}
		if(bm == "ingr"){
			$("#srcingr").load("chef/dishesdb.php",{
				srcingropt : $("input[name~='"+bm+"']").val()
			});
		}
	}
	function addDish(bm) {
		if(bm == "addDish"){
			var dis = false, cos = false, inc = false, wei = false;
			if ($("input[name~='dishname']").val() != "") {
				$("#dishwar").html("");
				dis = true;
			}
			if ($("input[name~='ingr']").val() != "") {
				$("#ingwar").html("");
				inc = true;
			}
			if (($("input[name~='gram']").val() != "") && ($("input[name~='gram']").val() > 0)) {
				$("#gramwar").html("");
				wei = true;
			}
			if ($("input[name~='cost']").val() != "") {
				$("#costwar").html("");
				cos = true;
			}
			if(!dis){
				$("#dishwar").html("Require");
			}
			if((!inc) && (ingrlist.length == 0)){
				$("#ingwar").html("Require");
			}
			if((!wei) && (ingrlist.length == 0)){
				$("#gramwar").html("Require");
			}
			if(!cos){
				$("#costwar").html("Require");
			}
			if(dis && ((inc && wei) || (ingrlist.length != 0)) && cos){
				//Validate Number or not
				wei = false;
				cos = false;
				if (!isNaN($("input[name~='gram']").val())) {
					//This is number
					wei = true;
				}
				if (!isNaN($("input[name~='cost']").val())) {
					//This is number
					cos = true;
				}
			    if(!wei){
			    	$("#gramwar").html("Require Number");
			    }
			    if(!cos){
			    	$("#costwar").html("Require Number");
			    }
			    var inid = false;
			    $.ajax({
					async:false,
				    url: "chef/dishesdb.php",
				    type: "POST",
				    data: {ingrs : $("input[name~='ingr']").val()},
				    success: function (result) {
				    	if (result != "NotExist") {
				    		ingrid[ingrlist.length] = JSON.parse(result);
				    		$("#ingwar").html("");
				    		inid = true;
				    	}else{
				    	   	$("#ingwar").html("This Ingredient is not Exist");
				    	   	inid = false;
				    }
				    },
				    error: function(jqXHR, textStatus, errorThrown) {
				        console.log(textStatus, errorThrown);
				    }
				});
			    if (wei && cos && inid) {
			    	inc = false;
			    	var stringrlist = "", strgramlist = "";
			    	if(ingrlist.length > 0){
			    		inc = true;
			    		var i = 0;
			    		while(i < ingrlist.length){
			    			if (i != (ingrlist.length - 1)) {
			    				stringrlist += ingrid[i]+"(*-)";
			    				strgramlist += gramlist[i]+"(*-)";
			    			}else{
			    				stringrlist += ingrid[i];
			    				strgramlist += gramlist[i];
			    			}
			    			i++;
			    		}
			    	}
			    	//Check Ingredient or Gram input field is empty
			    	if (($("input[name~='ingr']").val() != "") && ($("input[name~='gram']").val() != "")) {
			    		if (inc) {
			    			stringrlist += "(*-)"+ingrid[ingrlist.length];
			    			strgramlist += "(*-)"+$("input[name~='gram']").val();
			    		}else{
			    			stringrlist += ingrid[ingrlist.length];
			    			strgramlist += $("input[name~='gram']").val();
			    		}
			    	}
			    	$.ajax({
			    		url: "chef/dishesdb.php",
			    		type: "POST",
			    		data: {dis : $("input[name~='dishname']").val(), inc : stringrlist, wei : strgramlist, cos : $("input[name~='cost']").val()},
			    		success: function (result) {
			    		   	if (result == "Exist") {
			    	        	$("#warning").html("Already Exist !");
			    	        }
			    	        if (result == "Done") {
			    	        	location.reload();
			    	        }
			    	        console.log(result);
			    		},
			    		error: function(jqXHR, textStatus, errorThrown) {
			    		    console.log(textStatus, errorThrown);
			    		}
			    	});
				}
			}
		}
	}
</script>
</html>