<?php
    require 'logincheck.php';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<table class="navsub">
		<tr>
			<th><a class="nav" name="dishes" onclick="menu(this.name)">Dishes</a></th>
			<th><a class="nav" name="ingredients" onclick="menu(this.name)">Ingredients</a></th>
			<th><a class="nav" name="perishables" onclick="menu(this.name)">Damage Perishables</a></th>
			<th><a class="nav" name="warnpoint" onclick="menu(this.name)">Warning<span id="warnnot" style="color: green;padding: 5px;background-color: aliceblue;font-size: 125%;"></span></a></th>
			<th><a class="nav" name="alert" onclick="menu(this.name)">Alert<span id="alertnot" style="color: red;padding: 5px;background-color: aliceblue;font-size: 125%;"></span></a></th>
		</tr>
	</table>
	<p id="warning"></p>
	<p id="content2"></p>
</body>
<script type="text/javascript">
	let old_tagin = [];
	let old_tag = [];
	var page = getCookie("dashbo");
	var loaded = 0;

	if (page != null) {
		if(page == "ingredients"){
			$('#content2').load("chef/ingredients.php");
			loaded = 1;
		}
		if(page == "dishes"){
			$('#content2').load("chef/dishes.php");
			loaded = 1;
		}
		if(page == "perishables"){
			$('#content2').load("chef/perishable.php");
			loaded = 1;
		}
		if(page == "warnpoint"){
			$('#content2').load("chef/perishable.php");
			loaded = 1;
		}
		if(page == "alert"){
			$('#content2').load("chef/alert.php");
			loaded = 1;
		}
	}
	if (loaded == 0){
		$('#content2').load("chef/dishes.php");
	}
	function menu(bm) {
		if(bm == "ingredients"){
			createCookie("dashbo", "ingredients", "1");
			$('#content2').load("chef/ingredients.php");
		}
		if(bm == "dishes"){
			createCookie("dashbo", "dishes", "1");
			$('#content2').load("chef/dishes.php");
		}
		if(bm == "perishables"){
			createCookie("dashbo", "perishables", "1");
			$('#content2').load("chef/perishable.php");
		}
		if(bm == "warnpoint"){
			createCookie("dashbo", "warnpoint", "1");
			$('#content2').load("chef/warnpoint.php");
		}
		if(bm == "alert"){
			createCookie("dashbo", "alert", "1");
			$('#content2').load("chef/alert.php");
		}
	}
	function alert_noti() {
		$("#warnnot").load("chef/warnpointdb.php",{
			warnnot : 1
		});
		$("#alertnot").load("chef/alertdb.php",{
			alertnot : 1
		});
	}
	alert_noti();
	//---------------------Warning---------------------//
	function warning_disp(bm) {
		$("#warning").html(bm);
		setTimeout(function(){ warning_hide(); }, 5000);
	}
	function warning_hide() {
		$("#warning").html("");
	}
	//---------------------Warning---------------------//
</script>
</html>