<title>Alert</title>
<div id="load"></div>
<script type="text/javascript">
	$("#load").load("chef/alertdb.php",{
		load : "load"
	});
</script>