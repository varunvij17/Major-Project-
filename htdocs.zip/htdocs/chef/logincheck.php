<?php
    session_start();
    if(!(isset($_SESSION["username"]) && isset($_SESSION["password"]) && isset($_SESSION["hotelid"]))){
        echo "<script type='text/javascript'>";
        echo "$('#content1').load('chef/login.php');";
        echo "</script>";
    	exit();
    }
    if(isset($_SESSION["username"]) && isset($_SESSION["password"]) && isset($_SESSION["hotelid"])){
    	require 'dbconnect.php';
    	$sql = 'SELECT * FROM staffacc WHERE (stname="'.$_SESSION["username"].'" AND stpassword="'.$_SESSION["password"].'") AND sthotelid='.$_SESSION["hotelid"];
    	$result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
    	if($rowcount <= 0){
            echo "<script type='text/javascript'>";
            echo "$('#content1').load('chef/login.php');";
            echo "</script>";
            $conn->close();
            exit();
    	}
    	$conn->close();
    }
?>