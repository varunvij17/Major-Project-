<title>Warning</title>
<div id="load"></div>
<script type="text/javascript">
	$("#load").load("chef/warnpointdb.php",{
		load : "load"
	});
</script>