<!DOCTYPE html>
<html>
<head>
	<title>Ingredients</title>
</head>
<body>
	<table>
		<tr>
			<td><input type="text" name="ingredient" placeholder="Ingredient" list="srcingredient" oninput="srcing(this.name)" />
				<datalist id="srcingredient"></datalist>
			</td>
			<td><input type="text" name="weight" placeholder="Weight" /><br>
				<input type="text" name="ingrwarnpoint" placeholder="Set Weight Warn" /><br>
				<input type="text" name="ingrlimitpoint" placeholder="Set Weight limit Over" />
			</td>
			<td><select id="unit">
				<option value="g">Gram</option>
				<option value="k">Kilogram</option>
				<option value="m">Milliliter</option>
				<option value="l">Liter</option>
			</select></td>
			<td><select id="perish">
				<option value="nonperish">Non Perishable</option>
				<option value="perish">Perishable</option>
			</select></td>
			<td><input type="text" name="cost" placeholder="Cost" /></td>
			<td><a name="addingredients1" class="button" onclick="addInc(this.name)">Add / Search</a></td>
		</tr>
		<tr>
			<td id="incwar"></td>
			<td id="weiwar"></td>
			<td></td>
			<td id="coswar"></td>
			<td></td>
		</tr>
	</table>
	<p id="load"></p>
</body>
<script type="text/javascript">
	$("#load").load("chef/ingredientsdb.php",{
		load : "load"
	});
	function ingupdate(bm){
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/);
		if(bmname[0] == "alertedit") {
			let tag = "#trIng"+bmid[0];
			old_tagin[Number(bmid[0])] = $(tag).html();
			tag = "#warnpoint"+bmid[0];
			let warnpoint = $(tag).text();
			let build_tags = "<input type='text' name='wpts"+bmid[0]+"' value='"+warnpoint+"'>";
			$(tag).html(build_tags);
			tag = "#limitpoint"+bmid[0];
			let limitpoint = $(tag).text();
			build_tags = "<input type='text' name='lpts"+bmid[0]+"' value='"+limitpoint+"'>";
			$(tag).html(build_tags);
			tag = "#alertpointedit"+bmid[0];
			build_tags = "<button name='updatewpt"+bmid[0]+"' onclick='ingupdate(this.name)'>Update</button><button name='cancelwpt"+bmid[0]+"' onclick='ingupdate(this.name)'>Cancel</button>";
			$(tag).html(build_tags);
		}
		if(bmname[0] == "edit"){
			var trIng = "#ingredients"+bmid[0];
			var trWei = "#weight"+bmid[0];
			var trCos = "#cost"+bmid[0];
			var perishable = "#perishable"+bmid[0];
			var tredit = "#edit"+bmid[0];
			var str = "<input type='text' name='ingredients"+bmid[0]+"' value='"+$(trIng).text()+"'>";
			$(trIng).html(str);
			str = "<input type='text' name='weight"+bmid[0]+"' value='"+$(trWei).text()+"'>";
			$(trWei).html(str);
			str = "<input type='text' name='cost"+bmid[0]+"' value='"+$(trCos).text()+"'>";
			$(trCos).html(str);
			str = "<select id=\"perish"+bmid[0]+"\">";
			if (($(perishable).text() == "") || ($(perishable).text() == "nonperish")) {
				str += "<option value=\"nonperish\">Non Perishable</option>";
				str += "<option value=\"perish\">Perishable</option>";
			} else {
				str += "<option value=\"perish\">Perishable</option>";
				str += "<option value=\"nonperish\">Non Perishable</option>";
			}
			str += "</select>";
			$(perishable).html(str);
			str = "<button name='updateing"+bmid[0]+"' onclick='ingupdate(this.name)'>Update</button><button name='canceling"+bmid[0]+"' onclick='ingupdate(this.name)'>Cancel</button>";
			$(tredit).html(str);
		}
		if(bmname[0] == "canceling"){
			var trIng = "#ingredients"+bmid[0];
			var trWei = "#weight"+bmid[0];
			var trCos = "#cost"+bmid[0];
			var perishable = "#perishable"+bmid[0];
			var tredit = "#edit"+bmid[0];
			var str = $("input[name~='ingredients"+bmid[0]+"']").val();
			$(trIng).html(str);
			str = $("input[name~='weight"+bmid[0]+"']").val();
			$(trWei).html(str);
			str = $("input[name~='cost"+bmid[0]+"']").val();
			$(trCos).html(str);
			let selects = "#perish"+bmid[0]+" option:selected";
			str = $(selects).val();
			$(perishable).html(str);
			str = "<button name='edit"+bmid[0]+"' onclick='ingupdate(this.name)'>Edit</button>";
			$(tredit).html(str);
		}
		if(bmname[0] == "updateing"){
			var inc = false;
			var wei = false;
			var cos = false;
			let selects = "#perish"+bmid[0]+" option:selected";
			var emptywa = "#emptywa"+bmid[0];
		    if(!($(emptywa).length)){
		    	var str = "<tr id='emptywa"+bmid[0]+"'><td></td><td><p id='incwar"+bmid[0]+"'></p></td><td><p id='weiwar"+bmid[0]+"'></p></td><td><p id='coswar"+bmid[0]+"'></p></td><td></td><td></td></tr>";
		    	var tr = "#trIng"+bmid[0];
		    	$(tr).after(str);
		    }
			if ($("input[name~='ingredients"+bmid[0]+"']").val() != "") {
				var war = "#incwar"+bmid[0];
				$(war).html("");
				inc = true;
			}
			if ($("input[name~='weight"+bmid[0]+"']").val() != "") {
				var war = "#weiwar"+bmid[0];
				$(war).html("");
				wei = true;
			}
			if ($("input[name~='cost"+bmid[0]+"']").val() != "") {
				var war = "#coswar"+bmid[0];
				$(war).html("");
				cos = true;
			}
			if(!inc){
				var war = "#incwar"+bmid[0];
				$(war).html("Require");
			}
			if(!wei){
				var war = "#weiwar"+bmid[0];
				$(war).html("Require");
			}
			if(!cos){
				var war = "#coswar"+bmid[0];
				$(war).html("Require");
			}
			if(inc && wei && cos){
				$("#load").load("chef/ingredientsdb.php",{
					upinc : $("input[name~='ingredients"+bmid[0]+"']").val(),
					upwei : $("input[name~='weight"+bmid[0]+"']").val(),
					upcos : $("input[name~='cost"+bmid[0]+"']").val(),
					upingid : bmid[0],
					upperish : $(selects).val()
				});
			}
		}
	}
	function addInc(bm) {
		if(bm == "addingredients1"){
			var inc = false;
			var wei = false;
			var wei1 = false;
			var wei2 = false;
			var cos = false;
			if ($("input[name~='ingredient']").val() != "") {
				$("#incwar").html("");
				inc = true;
			}
			if ($("input[name~='weight']").val() != "") {
				$("#weiwar").html("");
				wei = true;
			}
			if (($("input[name~='ingrwarnpoint']").val() != "") && ($("input[name~='ingrwarnpoint']").val() > 0)) {
				$("#weiwar").html("");
				wei1 = true;
			}
			if (($("input[name~='ingrlimitpoint']").val() != "") && ($("input[name~='ingrlimitpoint']").val() > 0)) {
				$("#weiwar").html("");
				wei2 = true;
			}
			if ($("input[name~='cost']").val() != "") {
				$("#coswar").html("");
				cos = true;
			}
			if(!inc){
				$("#incwar").html("Require");
			}
			if(!wei){
				$("#weiwar").html("Require");
			}
			if(!wei1){
				$("#weiwar").html("Require");
			}
			if(!wei2){
				$("#weiwar").html("Require");
			}
			if(!cos){
				$("#coswar").html("Require");
			}
			if(inc && wei && wei1 && wei2 && cos){
				$("#load").load("chef/ingredientsdb.php",{
					inc : $("input[name~='ingredient']").val(),
					wei : $("input[name~='weight']").val(),
					kg : $('#unit option:selected').val(), 
					perish : $('#perish option:selected').val(),
					cos : $("input[name~='cost']").val(),
					warnpoint : $("input[name~='ingrwarnpoint']").val(),
					limitpoint : $("input[name~='ingrlimitpoint']").val()
				});
			}
		}
	}
	function srcing(bm) {
		if(bm == "ingredient"){
			$("#srcingredient").load("chef/ingredientsdb.php",{
				srcincopt : $("input[name~='"+bm+"']").val()
			});
			$("#load").load("chef/ingredientsdb.php",{
				srcinc : $("input[name~='"+bm+"']").val()
			});
		}
	}
</script>
</html>