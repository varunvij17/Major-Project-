<?php
	session_start();
    date_default_timezone_set('Asia/Kolkata');
    if (isset($_POST["load"])) {
    	perishable_items();
    }
    if (isset($_POST["warnnot"])) {
    	perishable_itemsnoti();
    }
    function perishable_itemsnoti() {
    	$hotid = $_SESSION["hotelid"];
    	$i = 0;
    	require 'dbconnect.php';
    	$sql = "SELECT * FROM ingredients WHERE hotid=$hotid AND weight BETWEEN limitpoint AND warningpoint";
    	$result = mysqli_query($conn,$sql);
    	$rowcount = mysqli_num_rows($result);
    	$conn->close();
    	echo $rowcount;
    }
    function perishable_items() {
    	$hotid = $_SESSION["hotelid"];
    	$i = 0;
    	require 'dbconnect.php';
    	$sql = "SELECT * FROM ingredients WHERE hotid=$hotid AND weight BETWEEN limitpoint AND warningpoint";
    	$result = mysqli_query($conn,$sql);
    	$str = "<table class=\"listtable\">";
    	$str .= "<tr>";
    	$str .= "<th>Sr no</th>";
    	$str .= "<th>Items</th>";
    	$str .= "<th>Weight(Kg / L)</th>";
    	$str .= "<th>Warning Weight(Kg / L)</th>";
    	$str .= "</tr>";
    	if(mysqli_num_rows($result) > 0) {
    		while ($row = mysqli_fetch_assoc($result)) {
    			$i++;
    			$str .= "<tr id=\"perishtr".$row["incid"]."\">";
    			$str .= "<td>".$i."</td>";
    			$str .= "<td id=\"itemtd".$row["incid"]."\">".$row["ingredient"]."</td>";
    			$str .= "<td id=\"weightconsttd".$row["incid"]."\">".$row["weight"]."</td>";
    			$str .= "<td id=\"weighttd".$row["incid"]."\">".$row["warningpoint"]."</td>";
    			$str .= "</tr>";
    		}
    	}
    	$conn->close();
    	$str .= "</table>";
    	echo $str;
    }
?>