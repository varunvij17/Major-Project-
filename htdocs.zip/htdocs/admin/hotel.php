<!DOCTYPE html>
<html>
<head>
	<title>Hotel</title>
</head>
<body>
	<p id="load"></p>
</body>
<script type="text/javascript">
	$("#load").load("admin/hoteldb.php",{
		hotel : "hotel"
	});
	var hotname = [],hotlocation = [],checkempty1 = [],checkempty2 = [];
	function add(bm) {
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/);
		if (bmname[0] == "hdelete") {
			$.post("admin/hoteldb.php",{
				del_hotel : bmid[0]
			});
			location.reload();
		}
		if (bmname[0] == "add"){
			//console.log(Number(bmid[0])+4);
			var str = "<td><br>"+bmid[0]+"</td><td><br><input type='text' name='hname' /></td><td><br><input type='text' name='hlocation' /></td><th><br><a name='hsub"+bmid[0]+"' onclick='add(this.name)'>Submit</a></th><th><br><a name='hcancel"+bmid[0]+"' onclick='add(this.name)'>Cancel</a></th>";
			var tag = "#hlist"+bmid[0];
			$(tag).html(str);
			str = "<td></td><td><p id='hname'></p></td><td><p id='hlocation'></p></td><th></th><th></th>";
			$("#addtag").html(str);
		}
		if (bmname[0] == "hcancel"){
			var str = "<th colspan='7'><a name='add"+bmid[0]+"' class='button' onclick='add(this.name)'>Add</a></th>";
			var tag = "#hlist"+bmid[0];
			$(tag).html("");
			$("#addtag").html(str);
		}
		if (bmname[0] == "hedit"){
			var hnameTag = "#htname"+bmid[0];
			var hlocationTag = "#htlocation"+bmid[0];
			var srnoTag = "#srno"+bmid[0];
			hotname[bmid[0]] = $(hnameTag).text();
			hotlocation[bmid[0]] = $(hlocationTag).text();
			var str = "<td id='srno"+bmid[0]+"'><br>"+$(srnoTag).text()+"</td><td><br><input type='text' name='uphname"+bmid[0]+"' value='"+$(hnameTag).text()+"' /></td><td><br><input type='text' name='uphlocation"+bmid[0]+"' value='"+$(hlocationTag).text()+"' /></td><th><br><a name='uphsub"+bmid[0]+"' onclick='add(this.name)'>Submit</a></th><th><br><a name='uphcancel"+bmid[0]+"' onclick='add(this.name)'>Cancel</a></th>";
			var tag = "#hlist"+$(srnoTag).text();
			$(tag).html(str);
			str = "<tr id='emptywa"+bmid[0]+"'><td></td><td><p id='uphname"+bmid[0]+"'></p></td><td><p id='uphlocation"+bmid[0]+"'></p></td><th></th><th></th></tr>";
			$(tag).after(str);
		}
		if (bmname[0] == "uphsub"){
			var srnoTag = "#srno"+bmid[0];
			var str = "<td id='srno"+bmid[0]+"'>"+$(srnoTag).text()+"</td><td id='htname"+bmid[0]+"'>"+$("input[name~='uphname"+bmid[0]+"']").val()+"</td><td id='htlocation"+bmid[0]+"'>"+$("input[name~='uphlocation"+bmid[0]+"']").val()+"</td><th><a name='hedit"+bmid[0]+"' onclick='add(this.name)'>Edit</a></th><th><a name='staffs"+bmid[0]+"' class='button' onclick='add(this.name)'>Add/Update</a></th><th><a name='details"+bmid[0]+"' onclick='add(this.name)'>Details</a></th><th><a name='hdelete"+bmid[0]+"' onclick='add(this.name)'>Delete</a></th>";
			var phname = "#uphname"+bmid[0];
			var phlocation = "#uphlocation"+bmid[0];
			if($("input[name~='uphname"+bmid[0]+"']").val() != ""){
				checkempty1[bmid[0]] = true;
				$(phname).html("");
			}else{
				$(phname).html("Require");
			}
			if($("input[name~='uphlocation"+bmid[0]+"']").val() != ""){
				checkempty2[bmid[0]] = true;
				$(phlocation).html("");
			}else{
				$(phlocation).html("Require");
			}
			if(checkempty1[bmid[0]] && checkempty2[bmid[0]]){
				$.post("admin/hoteldb.php", {uphno : bmid[0], uphname : $("input[name~='uphname"+bmid[0]+"']").val(), uphlocation : $("input[name~='uphlocation"+bmid[0]+"']").val()}, function(result){
					    //$("span").html(result);
				});
			    var tag = "#hlist"+bmid[0];
			    $(tag).html(str);
			}
		}
		if (bmname[0] == "uphcancel"){
			var srnoTag = "#srno"+bmid[0];
			var str = "";
			var emptywa = "#emptywa"+bmid[0];
			$(emptywa).remove();
			if(checkempty1[bmid[0]] && checkempty2[bmid[0]]){
				str = "<td id='srno"+bmid[0]+"'>"+$(srnoTag).text()+"</td><td id='htname"+bmid[0]+"'>"+$("input[name~='uphname']").val()+"</td><td id='htlocation"+bmid[0]+"'>"+$("input[name~='uphlocation']").val()+"</td><th><a name='hedit"+bmid[0]+"' onclick='add(this.name)'>Edit</a></th><th><a name='staffs"+bmid[0]+"' class='button' onclick='add(this.name)'>Add/Update</a></th><th><a name='details"+bmid[0]+"' onclick='add(this.name)'>Details</a></th><th><a name='hdelete"+bmid[0]+"' onclick='add(this.name)'>Delete</a></th>";
			}else{
				str = "<td id='srno"+bmid[0]+"'>"+$(srnoTag).text()+"</td><td id='htname"+bmid[0]+"'>"+hotname[bmid[0]]+"</td><td id='htlocation"+bmid[0]+"'>"+hotlocation[bmid[0]]+"</td><th><a name='hedit"+bmid[0]+"' onclick='add(this.name)'>Edit</a></th><th><a name='staffs"+bmid[0]+"' class='button' onclick='add(this.name)'>Add/Update</a></th><th><a name='details"+bmid[0]+"' onclick='add(this.name)'>Details</a></th><th><a name='hdelete"+bmid[0]+"' onclick='add(this.name)'>Delete</a></th>";
			}
			var tag = "#hlist"+bmid[0];
			$(tag).html(str);
		}
		if(bmname[0] == "hsub"){
			if($("input[name~='hname']").val() != ""){
				checkempty1[bmid[0]] = true;
				$("#hname").html("");
			}else{
				$("#hname").html("Require");
			}
			if($("input[name~='hlocation']").val() != ""){
				checkempty2[bmid[0]] = true;
				$("#hlocation").html("");
			}else{
				$("#hlocation").html("Require");
			}
			if(checkempty1[bmid[0]] && checkempty2[bmid[0]]){
				$("#load").load("admin/hoteldb.php",{
					hotelname : $("input[name~='hname']").val(),
					hotellocation : $("input[name~='hlocation']").val()
				});
			}
		}
		if(bmname[0] == "staffs"){
			var urlStr = location.protocol;
			urlStr = urlStr+"//"+location.hostname;
			urlStr = urlStr+"/staffsAcc.php?id="+bmid[0];
			window.open(urlStr);
		}
		if(bmname[0] == "details"){
			var urlStr = location.protocol;
			urlStr = urlStr+"//"+location.hostname;
			urlStr = urlStr+"/hoteldetails.php?id="+bmid[0];
			window.open(urlStr);
		}
	}
</script>
</html>