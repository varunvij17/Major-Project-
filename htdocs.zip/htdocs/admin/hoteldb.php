<?php
    session_start();
    if(isset($_POST["hotel"])){
    	listhotel1();
    }
    if(isset($_POST["del_hotel"])){
        delHotel($_POST["del_hotel"]);
    }
    if(isset($_POST["hotelname"]) && isset($_POST["hotellocation"])){
    	addhotel($_POST["hotelname"],$_POST["hotellocation"]);
    }
    if(isset($_POST["uphno"]) && isset($_POST["uphname"]) && isset($_POST["uphlocation"])){
    	uphotel($_POST["uphno"],$_POST["uphname"],$_POST["uphlocation"]);
    }
    function delHotel($hotid){
        //Delete Hotels//
        require 'dbconnect.php';
        $sql = "DELETE FROM dishes WHERE hotid=".$hotid;
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $sql = "DELETE FROM dishing WHERE hotid=".$hotid;
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $sql = "DELETE FROM hotel WHERE id=".$hotid;
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $sql = "DELETE FROM ingredients WHERE hotid=".$hotid;
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $sql = "DELETE FROM placeorder WHERE hotid=".$hotid;
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $sql = "DELETE FROM staffacc WHERE sthotelid=".$hotid;
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $conn->close();
    }
    function listhotel1(){
    	require 'dbconnect.php';
    	$sql = 'SELECT * FROM hotel';
        $result = mysqli_query($conn,$sql);
        echo "<table class='listtable'>";
        echo "<tr><th>Sr.No</th><th>Hotel Name</th><th>Location</th><th>Edit</th><th>Staff</th><th>Day</th><th>Delete</th></tr>";
        $plusTag = 1;
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
    			echo "<tr id='hlist".$plusTag."'><td id='srno".$row["id"]."'>".$plusTag."</td><td id='htname".$row["id"]."'>".$row["hotelname"]."</td><td id='htlocation".$row["id"]."'>".$row["location"]."</td><th><button name='hedit".$row["id"]."' onclick='add(this.name)'>Edit</button></th><th><a name='staffs".$row["id"]."' class='button' onclick='add(this.name)'>Add/Update</a></th><th><button name='details".$row["id"]."' onclick='add(this.name)'>Details</button></th><th><button name='hdelete".$row["id"]."' onclick='add(this.name)'>Delete</button></th></tr>";
    			$plusTag++;
    		}
        }
        echo "<tr id='hlist".$plusTag."'></tr>";
        echo "<tr id='addtag'><th colspan='7'><a name='add".$plusTag."' class='button' onclick='add(this.name)'>Add</a></th></tr>";
        echo "</table>";
    	$conn->close();
    }
    function addhotel($hotelname,$hotellocation){
    	require 'dbconnect.php';
    	$sql = "INSERT INTO hotel (hotelname, location) VALUES ('".$hotelname."', '".$hotellocation."')";
        if (mysqli_query($conn, $sql)) {
            // echo "New record created successfully";
            listhotel1();
        } else {
            // echo "Error: " . $sql . "" . mysqli_error($conn);
        }
    	$conn->close();
    }
    function uphotel($id,$hotelname,$hotellocation){
    	require 'dbconnect.php';
    	$sql = "UPDATE hotel SET hotelname='".$hotelname."', location='".$hotellocation."' WHERE id=".$id;
        if (mysqli_query($conn, $sql)) {
            // echo "New record created successfully";
        } else {
            // echo "Error: " . $sql . "" . mysqli_error($conn);
        }
    	$conn->close();
    }
?>