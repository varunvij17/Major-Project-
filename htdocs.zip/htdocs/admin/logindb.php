<?php
    session_start();
    if(isset($_POST["username"]) && isset($_POST["password"])){
        require 'dbconnect.php';
        $sql = 'SELECT * FROM admin WHERE username="'.$_POST["username"].'" AND password="'.md5($_POST["password"]).'"';
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
            $_SESSION["username"] = $_POST["username"];
            $_SESSION["password"] = $_POST["password"];
            $_SESSION["who"] = "admin";
            echo "done";
        }
        $conn->close();
    }
?>