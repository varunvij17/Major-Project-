<!DOCTYPE html>
<html>
<head>
	<title id="tabname"></title>
	<script type="text/javascript">
		$("#tabname").load("admin/detailsdb.php",{
			hname : window.location.href
		});
	</script>
</head>
<body>
	<p id="load"></p>
</body>
<script type="text/javascript">
	$("#load").load("admin/detailsdb.php",{
		hotel : window.location.href
	});
</script>
</html>