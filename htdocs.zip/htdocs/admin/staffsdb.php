<?php
    session_start();
    if(isset($_POST["url0"])){
    	$urlArray = explode("=", $_POST["url0"]);
    	listStaff1($urlArray[1]);
    }
    if(isset($_POST["stusername"]) && isset($_POST["userpass"]) && isset($_POST["position"]) && isset($_POST["url1"])){
    	$urlArray = explode("=", $_POST["url1"]);
    	insertstaff($urlArray[1],$_POST["position"],$_POST["stusername"],$_POST["userpass"]);
    }
    if(isset($_POST["upstusername"]) && isset($_POST["upuserpass"]) && isset($_POST["upposition"]) && isset($_POST["upstid"]) && isset($_POST["upurl1"])){
    	$urlArray = explode("=", $_POST["upurl1"]);
    	updatestaff($urlArray[1],$_POST["upposition"],$_POST["upstusername"],$_POST["upuserpass"],$_POST["upstid"]);
    }
    function updatestaff($hotelid,$position,$stusername,$stuserpass,$stid){
    	require 'dbconnect.php';
        $sql = "UPDATE staffacc SET stname='".$stusername."', stpassword='".$stuserpass."' WHERE sthotelid=".$hotelid." AND stid=".$stid;
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
            listStaff1($hotelid);
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $conn->close();
    }
    function insertstaff($hotelid,$position,$stusername,$userpass){
    	require 'dbconnect.php';
        $sql = "INSERT INTO staffacc(sthotelid,stposition,stname,stpassword)VALUES (".$hotelid.",'".$position."','".$stusername."','".$userpass."')";
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
            listStaff1($hotelid);
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $conn->close();
    }
    function listStaff1($hotelid){
    	require 'dbconnect.php';
        echo "<table class='listtable'>";
        $sql = "SELECT * FROM hotel WHERE id=".$hotelid;
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	echo "<tr><th colspan='5'>".$row["hotelname"]."</th></tr>";
            }
        }
        $conn->close();
        require 'dbconnect.php';
        echo "<tr><th>Sr.No</th><th>Position</th><th>Username</th><th>Password</th><th>Edit</th></tr>";
        //Chef
    	$sql = "SELECT * FROM staffacc WHERE sthotelid=".$hotelid." AND stposition='chef'";
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        if($rowcount > 0){
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
            display($hotelid,"chef",1,$row["stid"],$row["stname"],$row["stpassword"]);
        }else{
        	//Insert or Add Staff
        	addstaff($hotelid,"chef",1);
        }
        $conn->close();
        require 'dbconnect.php';
        //Kitchen
    	$sql = "SELECT * FROM staffacc WHERE sthotelid=".$hotelid." AND stposition='kitchen'";
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        if($rowcount > 0){
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
            display($hotelid,"kitchen",2,$row["stid"],$row["stname"],$row["stpassword"]);
        }else{
        	//Insert or Add Staff
        	addstaff($hotelid,"kitchen",2);
        }
        $conn->close();
        require 'dbconnect.php';
        //Others
    	$sql = "SELECT * FROM staffacc WHERE sthotelid=".$hotelid." AND stposition='others'";
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        if($rowcount > 0){
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
            display($hotelid,"others",3,$row["stid"],$row["stname"],$row["stpassword"]);
        }else{
        	//Insert or Add Staff
        	addstaff($hotelid,"others",3);
        }
        echo "</table>";
    	$conn->close();
    }
    function addstaff($hotelid,$position,$srno){
    	echo "<tr id='".$position."1'><td>".$srno."</td><td>".$position."</td><td><input type='text' name='".$position."name1' /></td><td><input type='text' name='".$position."pass1' /></td><td><a name='".$position."sub1' onclick='addst(this.name)'>Submit</a></td></tr>";
    }
    function display($hotelid,$position,$srno,$stid,$stname,$stpassword){
    	echo "<tr id='".$position."1'><td>".$srno."</td><td>".$position."</td><td id='".$position."stname".$stid."'>".$stname."</td><td id='".$position."stpass".$stid."'>".$stpassword."</td><td id='".$position."edit1'><a name='".$position."stedit".$stid."' onclick='addst(this.name)'>Edit</a></td></tr>";
    }
?>