<?php
	session_start();
    date_default_timezone_set('Asia/Kolkata');
    if(isset($_POST["hname"])){
    	$urlArray = explode("=", $_POST["hname"]);
    	hname($urlArray[1]);
    }
    if(isset($_POST["hotel"])){
    	$urlArray = explode("=", $_POST["hotel"]);
    	listdetails($urlArray[1]);
    }
    function listdetails($hotelid){
    	require 'dbconnect.php';
    	echo "<p class='subhead'>Dish :</p>";
    	$today = date("Ymd");
    	$alldishtotalprice = 0.0;
        //$sql = "SELECT * FROM placeorder a, dishes b WHERE (a.hotid=".$hotelid." AND a.process='done') AND (b.disid=a.dishid AND b.hotid=a.hotid)";
        $sql = "SELECT DISTINCT dishid FROM placeorder WHERE (hotid=".$hotelid." AND process='done') AND orderid LIKE '%".$today."%'";
        $result = mysqli_query($conn,$sql);
        echo "<table class='listtable'>";
        echo "<tr><th>Dish</th><th>Price</th><th>Qty</th><th>Total Price</th></tr>";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	echo "<tr>".dishname($hotelid,$row["dishid"]).qtytotal($hotelid,$row["dishid"],$today)."</tr>";
            	$alldishtotalprice += dishtotal($hotelid,$row["dishid"],$today);
            }
        }
        echo "<tr><th>Total</th><td colspan='2'></td><th>".$alldishtotalprice."</th></tr>";
        echo "</table>";
        $conn->close();
    	require 'dbconnect.php';
    	echo "<p class='subhead'>Stock :</p>";
    	$alldishtotalprice = 0.0;
        $sql = "SELECT * FROM ingredients WHERE hotid=".$hotelid;
        $result = mysqli_query($conn,$sql);
        echo "<table class='listtable'>";
        echo "<tr><th colspan='2'></th><th colspan='3'>WEIGHT (Kg)</th></tr>";
        echo "<tr><th>Ingredients</th><th>Cost</th><th>Total</th><th>Balance</th><th>Used</th></tr>";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	//echo "<tr>".dishname($hotelid,$row["dishid"]).qtytotal($hotelid,$row["dishid"],$today)."</tr>";
            	//$alldishtotalprice += dishtotal($hotelid,$row["dishid"],$today);
            	echo "<tr><td>".$row["ingredient"]."</td><td>".$row["cost"]."</td>".getingrweightTotal($hotelid,$row["incid"],$row["weight"],$today)."</tr>";
            }
        }
        //echo "<tr><th>Total</th><td colspan='2'></td><th>".$alldishtotalprice."</th></tr>";
        echo "</table>";
        // Yesterday //
        require 'dbconnect.php';
        echo "<p class='subhead'>Stock Yesterday: ".date("l-d-m-Y",strtotime("-1 days"))."</p>";
        $sql = "SELECT * FROM ingredients WHERE hotid=".$hotelid;
        $result = mysqli_query($conn,$sql);
        echo "<table class='listtable'>";
        echo "<tr><th colspan='2'></th><th colspan='3'>WEIGHT (Kg)</th></tr>";
        echo "<tr><th>Ingredients</th><th>Cost</th><th>Total</th><th>Balance</th><th>Used</th></tr>";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                echo "<tr><td>".$row["ingredient"]."</td><td>".$row["ycost"]."</td><td>".$row["ytotal"]."</td><td>".$row["ybalance"]."</td><td>".$row["yused"]."</td></tr>";
            }
        }
        echo "</table>";
        // Yesterday //

        $conn->close();
        // Damage Ingredients //
        $current = date("d-m-Y");
        require 'dbconnect.php';
        $sql = "SELECT * FROM ingredients WHERE (hotid=$hotelid AND incdate='$current') AND damageweight > 0";
        $result = mysqli_query($conn,$sql);
        echo "<br><br><br><p class='subhead'>Damage :</p>";
        echo "<br><br><br><table class='listtable'>";
        echo "<tr><th>Sr.No</th><th>Ingredients</th><th>Weight(Kg)</th><th>Cost</th><th>Perishable</th></tr>";
        if(mysqli_num_rows($result) > 0){
            $i = 1;
            while ($row = mysqli_fetch_assoc($result)){
                echo "<tr id='trIng".$row["incid"]."'><td>".$i."</td><td id='ingredients".$row["incid"]."'>".$row["ingredient"]."</td><td id='weight".$row["incid"]."'>".$row["damageweight"]."</td><td id='cost".$row["incid"]."'>".$row["damagecost"]."</td><td id='perishable".$row["incid"]."'>".$row["perishable"]."</td></tr>";
                $i++;
            }
        }
        echo "</table>";
        $conn->close();
        // Damage Ingredients //
    }
    function getingrweightTotal($hotelid,$ingrid,$ingrweiKg,$today){
    	require 'dbconnect.php';
    	$gram = 0.0;
    	$sql = "SELECT * FROM placeorder a,dishing b WHERE ((a.process='done' AND a.orderid LIKE '%".$today."%') AND (b.dishid=a.dishid AND a.hotid=".$hotelid.")) AND (b.hotid=a.hotid AND b.ingrid=".$ingrid.")";
    	$result = mysqli_query($conn,$sql);
		if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	$gram += $row["gram"] * $row["qty"];
            }
        }
		$conn->close();
		$gram /= 1000;
		$str = "<td>".$ingrweiKg."</td><td>".$gram."</td>";
		$gram += $ingrweiKg;
		$str = "<td>".$gram."</td>".$str;
		return $str;
    }
    function qtytotal($hotelid,$dishid,$today){
    	require 'dbconnect.php';
    	$qty = 0;
    	$qtyprice = 0.0;
        $sql = "SELECT qty,qtyprice FROM placeorder WHERE (hotid=".$hotelid." AND dishid=".$dishid.") AND (process='done' AND orderid LIKE '%".$today."%')";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
			while ($row = mysqli_fetch_assoc($result)){
				$qty += $row["qty"];
				$qtyprice += $row["qtyprice"];
			}
		}
        $conn->close();
        $str = "<td>".$qty."</td><td>".$qtyprice."</td>";
        return $str;
    }
    function dishtotal($hotelid,$dishid,$today){
    	require 'dbconnect.php';
    	$qtyprice = 0.0;
        $sql = "SELECT qtyprice FROM placeorder WHERE (hotid=".$hotelid." AND dishid=".$dishid.") AND (process='done' AND orderid LIKE '%".$today."%')";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
			while ($row = mysqli_fetch_assoc($result)){
				$qtyprice += $row["qtyprice"];
			}
		}
        $conn->close();
        return $qtyprice;
    }
    function dishname($hotelid,$dishid){
    	require 'dbconnect.php';
        $sql = "SELECT dish,price FROM dishes WHERE hotid=".$hotelid." AND disid=".$dishid;
        $result = mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result);
        $conn->close();
        $str = "<td>".$row["dish"]."</td><td>".$row["price"]."</td>";
        return $str;
    }
    function hname($hotelid){
    	require 'dbconnect.php';
        $sql = "SELECT hotelname FROM hotel WHERE id=".$hotelid;
        $result = mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result);
        echo ucwords($row["hotelname"]);
        $conn->close();
    }
?>