<?php
    session_start();
    if(!(isset($_SESSION["username"]) && isset($_SESSION["password"]))){
        echo "<script type='text/javascript'>";
        echo "$('#content1').load('admin/login.php');";
        echo "</script>";
    	exit();
    }
    if(isset($_SESSION["username"]) && isset($_SESSION["password"])){
    	require 'dbconnect.php';
    	$sql = 'SELECT * FROM admin WHERE username="'.$_SESSION["username"].'" AND password="'.md5($_SESSION["password"]).'"';
    	$result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
    	if($rowcount <= 0){
            echo "<script type='text/javascript'>";
            echo "$('#content1').load('admin/login.php');";
            echo "</script>";
            $conn->close();
            exit();
    	}
    	$conn->close();
    }
?>