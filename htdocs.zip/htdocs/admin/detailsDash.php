<?php
    require 'logincheck.php';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<table>
		<tr>
			<th id="hname">Manage Staffs Acc</th>
		</tr>
	</table>
	<p id="warning"></p>
	<p id="content2"></p>
</body>
<script type="text/javascript">
	$("#hname").load("admin/detailsdb.php",{
		hname : window.location.href
	});
	$("#content2").load("admin/details.php");
</script>
</html>