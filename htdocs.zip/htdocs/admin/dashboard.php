<?php
    require 'logincheck.php';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<table class="navsub">
		<tr>
			<th><a class="nav" name="hotel" onclick="menu(this.name)">Hotel</a></th>
		</tr>
	</table>
	<p id="warning"></p>
	<p id="content2"></p>
</body>
<script type="text/javascript">
	var page = getCookie("dashbo");
	var loaded = 0;

	if (page != null) {
		if(page == "hotel"){
			$('#content2').load("admin/hotel.php");
			loaded = 1;
		}
	}
	if (loaded == 0){
		$('#content2').load("admin/hotel.php");
	}
	function menu(bm) {
		if(bm == "hotel"){
			createCookie("dashbo", "hotel", "1");
			$('#content2').load("admin/hotel.php");
		}
	}
</script>
</html>