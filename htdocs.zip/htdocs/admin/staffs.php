<!DOCTYPE html>
<html>
<head>
	<title>Staff Acc</title>
</head>
<body>
	<p id="load"></p>
</body>
<script type="text/javascript">
	$("#load").load("admin/staffsdb.php",{
		url0 : window.location.href
	});
	var checkempty1 = [],checkempty2 = [];
	function addst(bm) {
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/);
		if (bmname[0] == "chefsub"){
			submition("#chef1",bm,bmname[0],"chefname1","chefpass1");
		}
		if (bmname[0] == "kitchensub"){
			submition("#kitchen1",bm,bmname[0],"kitchenname1","kitchenpass1");
		}
		if (bmname[0] == "otherssub"){
			submition("#others1",bm,bmname[0],"othersname1","otherspass1");
		}
		if (bmname[0] == "chefstedit"){
			editst("chefstname","chefstpass","chefedit1","chefnameinput","chefpassinput","upchef",bmid[0]);
		}
		if (bmname[0] == "kitchenstedit"){
			editst("kitchenstname","kitchenstpass","kitchenedit1","kitchennameinput","kitchenpassinput","upkitchen",bmid[0]);
		}
		if (bmname[0] == "othersstedit"){
			editst("othersstname","othersstpass","othersedit1","othersnameinput","otherspassinput","upothers",bmid[0]);
		}
		if (bmname[0] == "upchef"){
			updatest("#chef1",bm,bmname[0],"chefnameinput","chefpassinput",bmid[0]);
		}
		if (bmname[0] == "upkitchen"){
			updatest("#kitchen1",bm,bmname[0],"kitchennameinput","kitchenpassinput",bmid[0]);
		}
		if (bmname[0] == "upothers"){
			updatest("#others1",bm,bmname[0],"othersnameinput","otherspassinput",bmid[0]);
		}
	}
	function editst(name,pass,edit,nameinput,passinput,upstaff,stid) {
		var tag = "#"+name+stid;
		var str = "<input name='"+nameinput+"' value='"+$(tag).text()+"' />";
		$(tag).html(str);
		tag = "#"+pass+stid;
		str = "<input name='"+passinput+"' value='"+$(tag).text()+"' />";
		$(tag).html(str);
		tag = "#"+edit;
		str = "<a name='"+upstaff+stid+"' onclick='addst(this.name)'>Update</a>";
		$(tag).html(str);
	}
	function updatest(tr,bm,bmname,name,pass,stid) {
		var emptywa = "#emptywa"+bmname;
		if(!($(emptywa).length)){
			var str = "<tr id='emptywa"+bmname+"'><td></td><td></td><td><p id='upname"+bmname+"'></p></td><td><p id='uppass"+bmname+"'></p></td><td></td></tr>";
			$(tr).after(str);
		}
			checkempty1[bm] = false;
			checkempty2[bm] = false;
			if($("input[name~='"+name+"']").val() != ""){
				var tagPname = "#upname"+bmname;
				$(tagPname).html("");
				checkempty1[bm] = true;
			}
			if($("input[name~='"+pass+"']").val() != ""){
				var tagPpass = "#uppass"+bmname;
				$(tagPpass).html("");
				checkempty2[bm] = true;
			}
			if (!checkempty1[bm]) {
				var tagPname = "#upname"+bmname;
				$(tagPname).html("Require");
			}
			if (!checkempty2[bm]) {
				var tagPpass = "#uppass"+bmname;
				$(tagPpass).html("Require");
			}
			if(checkempty1[bm] && checkempty2[bm]){
				var position = "";
				if (bmname == "upchef") {
					position = "chef";
				}
				if (bmname == "upkitchen") {
					position = "kitchen";
				}
				if (bmname == "upothers") {
					position = "others";
				}
				$("#load").load("admin/staffsdb.php", {
					upstusername : $("input[name~='"+name+"']").val(), upuserpass : $("input[name~='"+pass+"']").val(), upposition : position, upstid : stid, upurl1 : window.location.href
				});
			}
	}
	function submition(tr,bm,bmname,name,pass) {
		var emptywa = "#emptywa"+bmname;
		if(!($(emptywa).length)){
			var str = "<tr id='emptywa"+bmname+"'><td></td><td></td><td><p id='upname"+bmname+"'></p></td><td><p id='uppass"+bmname+"'></p></td><td></td></tr>";
			$(tr).after(str);
		}
			checkempty1[bm] = false;
			checkempty2[bm] = false;
			if($("input[name~='"+name+"']").val() != ""){
				var tagPname = "#upname"+bmname;
				$(tagPname).html("");
				checkempty1[bm] = true;
			}
			if($("input[name~='"+pass+"']").val() != ""){
				var tagPpass = "#uppass"+bmname;
				$(tagPpass).html("");
				checkempty2[bm] = true;
			}
			if (!checkempty1[bm]) {
				var tagPname = "#upname"+bmname;
				$(tagPname).html("Require");
			}
			if (!checkempty2[bm]) {
				var tagPpass = "#uppass"+bmname;
				$(tagPpass).html("Require");
			}
			if(checkempty1[bm] && checkempty2[bm]){
				var position = "";
				if (bm == "chefsub1") {
					position = "chef";
				}
				if (bm == "kitchensub1") {
					position = "kitchen";
				}
				if (bm == "otherssub1") {
					position = "others";
				}
				$("#load").load("admin/staffsdb.php", {
					stusername : $("input[name~='"+name+"']").val(), userpass : $("input[name~='"+pass+"']").val(), position : position, url1 : window.location.href
				});
			}
	}
</script>
</html>