<?php
    session_start();
    if(isset($_SESSION["username"]) && isset($_SESSION["password"])){
    	require 'dbconnect.php';
    	$sql = 'SELECT * FROM admin WHERE username="'.$_SESSION["username"].'" AND password="'.md5($_SESSION["password"]).'"';
    	$result = mysqli_query($conn,$sql);
    	if(mysqli_num_rows($result) > 0){
    		$conn->close();
    		echo "<script type='text/javascript'>";
            echo "$('#content1').load('admin/dashboard.php');";
            echo "</script>";
    		exit();
    	}
    	$conn->close();
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
</head>
<body>
	<table class="formtable">
		<tr>
			<td colspan="3" class="warningerror" id="warning"></td>
		</tr>
		<tr>
			<th colspan="3" class="formhead">Admin Login</th>
		</tr>
	    <tr>
	        <th class="formcontent">Username</th>
	        <th class="formcontent">:</th>
	        <td><input type='text' name='username' class="inputfield" /></td>
	    </tr>
	    <tr>
	    	<td></td><td></td><td id="username"></td>
	    </tr>
	    <tr>
	        <th class="formcontent">Password</th>
	        <th class="formcontent">:</th>
	        <td><input type='password' name='password' class="inputfield" /></td>
	    </tr>
	    <tr>
	    	<td></td><td></td><td id="password"></td>
	    </tr>
	    <tr>
	        <th colspan='3'><a name='logbutton' class="button" onclick="login(this.name)">Login</a></th>
	    </tr>
    </table>
</body>
<script type="text/javascript">
	function login(bm) {
		if(bm == "logbutton"){
			var notempty1 = false;
			var notempty2 = false;
			if($("input[name~='username']").val() != ""){
				notempty1 = true;
				$("#username").html("");
			}
			if (!notempty1) {
				$("#username").html("Required");
			}
			if($("input[name~='password']").val() != ""){
				notempty2 = true;
				$("#password").html("");
			}
			if (!notempty2) {
				$("#password").html("Required");
			}
			if (notempty1 && notempty2) {
				$.post("admin/logindb.php",{
					username : $("input[name~='username']").val(),
					password : $("input[name~='password']").val()
				},
					function(result){
					    if(result == "done"){
					    	location.reload();
					    }else{
					    	$("#warning").html("Username or Password invalid !");
					    }
					}
				);
			}
		}
	}
</script>
</html>