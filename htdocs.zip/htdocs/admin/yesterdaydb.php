<?php
    // Yesterday //
    function yesterday() {
        $today = date("Ymd",strtotime("-1 days"));
        $resetdamagedate = date("Ymd");
        require 'dbconnect.php';
        $sql = "SELECT * FROM ingredients";
        $result = mysqli_query($conn,$sql);
        // echo "<table class='listtable'>";
        // echo "<tr><th colspan='2'></th><th colspan='3'>WEIGHT (Kg)</th></tr>";
        // echo "<tr><th>Ingredients</th><th>Cost</th><th>Total</th><th>Balance</th><th>Used</th></tr>";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                /*echo "<tr><td>".$row["ingredient"]."</td><td>".$row["cost"]."</td>".getingrweightTotalyesterday($row["hotid"],$row["incid"],$row["weight"],$today)."</tr>";*/
                if ($row["ydate"] != $today) {
                    getingrweightTotalyesterday($row["ingredient"],$row["cost"],$row["hotid"],$row["incid"],$row["weight"],$today);
                    resetdamage($row["incid"], $row["hotid"], $resetdamagedate);
                }
            }
        }
        // echo "</table>";
        $conn->close();
    }
    function resetdamage($incid, $hotelid, $resetdamagedate) {
        require 'dbconnect.php';
        $sql = "SELECT * FROM ingredients WHERE resetdamagedate!='$resetdamagedate'";
        $result = mysqli_query($conn,$sql);
        $resetbool = false;
        if(mysqli_num_rows($result) > 0) {
            $resetbool = true;
        }
        $conn->close();
        if ($resetbool) {
            require 'dbconnect.php';
            $sql = "UPDATE ingredients SET damageweight=0, damagecost=0, resetdamagedate='$resetdamagedate' WHERE incid=$incid AND hotid=$hotelid";
            if (mysqli_query($conn, $sql)) {
                //echo "Record updated successfully";
                // listIngredients();
            } else {
                //echo "Error updating record: " . mysqli_error($conn);
            }
            $conn->close();
        }
    }
    function getingrweightTotalyesterday($ingredient,$cost,$hotelid,$ingrid,$ingrweiKg,$today)  {
        $bool = false;
        require 'dbconnect.php';
        $gram = 0.0;
        $sql = "SELECT * FROM placeorder a,dishing b WHERE ((a.process='done' AND a.orderid LIKE '%".$today."%') AND (b.dishid=a.dishid AND a.hotid=".$hotelid.")) AND (b.hotid=a.hotid AND b.ingrid=".$ingrid.")";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                $gram += $row["gram"] * $row["qty"];
            }
            $bool = true;
        }
        $conn->close();
        $gram /= 1000;
        // $str = "<td>".$ingrweiKg."</td><td>".$gram."</td>";
        $gram += $ingrweiKg;
        // $str = "<td>".$gram."</td>".$str;
        if ($bool) {
            require 'dbconnect.php';
            $sql = "UPDATE ingredients SET ycost=$cost, ytotal=$gram, ybalance=$ingrweiKg, yused=$gram, ydate='$today' WHERE incid=$ingrid AND hotid=$hotelid";
            if (mysqli_query($conn, $sql)) {
                //echo "Record updated successfully";
                // listIngredients();
            } else {
                //echo "Error updating record: " . mysqli_error($conn);
            }
            $conn->close();
        } else {
             require 'dbconnect.php';
            $sql = "UPDATE ingredients SET ycost=0, ytotal=0, ybalance=0, yused=0, ydate='' WHERE incid=$ingrid AND hotid=$hotelid";
            if (mysqli_query($conn, $sql)) {
                //echo "Record updated successfully";
                // listIngredients();
            } else {
                //echo "Error updating record: " . mysqli_error($conn);
            }
            $conn->close();
        }
        // return $str;
    }
    // Yesterday //
?>