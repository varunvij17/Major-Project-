<!DOCTYPE html>
<html>
<head>
	<title>Cancel Order</title>
</head>
<body>
	<p id="cancelorders"></p>
</body>
<script type="text/javascript">
	cancelist();
	var timerc = setInterval(cancelist ,20000);
	function cancelist() {
		if ($("#cancelorders").length > 0) {
			$("#cancelorders").load("staff/cancelorderdb.php",{
				cancelnoti : "cancel"
			});
		}else{
			clearInterval(timerc);
		}
	}
	function cancelorder(bm){
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/g);
		if (bmname[0] == "cancel") {
			$("#cancelorders").load("staff/cancelorderdb.php",{
				orderid : bmid[0]
			});
			notification();
		}
	}
</script>
</html>