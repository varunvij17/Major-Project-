<!DOCTYPE html>
<html>
<head>
	<title>Delivery Order</title>
</head>
<body>
	<p id="delivery"></p>
</body>
<script type="text/javascript">
	orderdeliverylist();
	var timerd = setInterval(orderdeliverylist ,20000);
	function orderdeliverylist() {
		if ($("#delivery").length > 0) {
			$("#delivery").load("staff/deliverydb.php",{
				cancelnoti : "cancel"
			});
		}else{
			clearInterval(timerd);
		}
	}
	function orderdeli(bm){
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/g);
		if (bmname[0] == "done") {
			$("#delivery").load("staff/deliverydb.php",{
				orderid : bmid[0]
			});
			notification();
		}
	}
</script>
</html>