<?php
    session_start();
    date_default_timezone_set('Asia/Kolkata');
    if(isset($_POST["cancelnoti"])){
    	cancelnoti();
    }
    if(isset($_POST["deliverynoti"])){
    	orderdelivery();
    }
    function cancelnoti(){
    	require 'dbconnect.php';
    	$sql = "SELECT DISTINCT orderid,placetime FROM placeorder WHERE process!='done' AND hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        $i = 0;
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
            	$start = strtotime($row["placetime"]);
            	$end = strtotime(date('Y-m-d H:i:s'));
            	$min = (int)(($end - $start) / 60);
                $day = (int)(($end - $start) / 18000);
                $day = ($day > 0 ) ? $day :($day * -1);
            	if($min > 30){
                    if ($day > 0) {
                        //Automatic order cancel (record Delete)
                        cancelorder($row["orderid"]);
                    }
                    if ($day <= 0) {
                        $i++;
                    }
            	}
            }
        }
        if ($i > 0) {
        	echo $i;
        }
    	$conn->close();
    }
    function orderdelivery(){
    	require 'dbconnect.php';
    	$sql = "SELECT DISTINCT orderid,placetime FROM placeorder WHERE process='accept' AND hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        $i = 0;
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                $i++;
            }
        }
        if ($i > 0) {
        	echo $i;
        }
    	$conn->close();
    }
    function cancelorder($orderid){
        require 'dbconnect.php';
        $sql = "DELETE FROM placeorder WHERE orderid=".$orderid." AND hotid=".$_SESSION["hotelid"];
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $conn->close();
    }
?>