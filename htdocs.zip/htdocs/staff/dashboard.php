<?php
    require 'logincheck.php';
?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<table class="navsub">
		<tr>
			<th colspan="3" style="color: #dcdcdc;">ORDER</th>
		</tr>
		<tr>
			<th><a class="nav" name="order" onclick="menu(this.name)">Place</a></th>
			<th><a class="nav" name="cancelorder" onclick="menu(this.name)">Cancel<span id="cancelnoti"></span></a></th>
			<th><a class="nav" name="delivery" onclick="menu(this.name)">Delivery<span id="deliverynoti"></span></a></th>
		</tr>
	</table>
	<p id="warning"></p>
	<p id="content2"></p>
</body>
<script type="text/javascript">
	var page = getCookie("dashbo");
	var loaded = 0;

	if (page != null) {
		if(page == "order"){
			$('#content2').load("staff/order.php");
			loaded = 1;
		}
		if(page == "cancelorder"){
			$('#content2').load("staff/cancelorder.php");
			loaded = 1;
		}
		if(page == "delivery"){
			$('#content2').load("staff/delivery.php");
			loaded = 1;
		}
	}
	if (loaded == 0){
		$('#content2').load("staff/order.php");
	}
	function menu(bm) {
		reset();
		if(bm == "order"){
			createCookie("dashbo", "order", "1");
			$('#content2').load("staff/order.php");
		}
		if(bm == "cancelorder"){
			createCookie("dashbo", "cancelorder", "1");
			$('#content2').load("staff/cancelorder.php");
		}
		if(bm == "delivery"){
			createCookie("dashbo", "delivery", "1");
			$('#content2').load("staff/delivery.php");
		}
	}
</script>
<script type="text/javascript" src="staff/notification.js"></script>
</html>