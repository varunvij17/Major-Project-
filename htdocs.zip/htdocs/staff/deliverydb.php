<?php
    session_start();
    date_default_timezone_set('Asia/Kolkata');
    if(isset($_POST["cancelnoti"])){
    	orderdelivery();
    }
    if(isset($_POST["orderid"])){
        doneorder($_POST["orderid"]);
        orderdelivery();
    }
    function orderdelivery(){
    	require 'dbconnect.php';
    	$sql = "SELECT DISTINCT orderid,placetime FROM placeorder WHERE process='accept' AND hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        echo "<table class='listtable'>";
        echo "<tr><th>Table.no</th><th>Order</th><th>Qty</th><th>Time</th><th>Done</th></tr>";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                echo displayDeliveryOrder($row["orderid"]);
            }
        }
        echo "</table>";
    	$conn->close();
    }
    function displayDeliveryOrder($orderid){
        require 'dbconnect.php';
        $sql = "SELECT * FROM placeorder a,dishes b WHERE (a.orderid=".$orderid." AND a.hotid=".$_SESSION["hotelid"].") AND b.disid=a.dishid";
        $result = mysqli_query($conn,$sql);
        $dish = "";
        $qty = "";
        $times = "";
        $tableno = "";
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                $dish .= $row["dish"]."<br>";
                $qty .= $row["qty"]."<br>";
                $times = explode(" ", $row["placetime"]);
                $tableno = $row["tableno"];
            }
            $str = "<tr id='".$orderid."'><td>".$tableno."</td><td>".$dish."</td><td>".$qty."</td><td>".$times[1]."</td><th><a class='button' name='done".$orderid."' onclick='orderdeli(this.name)'>Done</a></th></tr>";
            $conn->close();
            return $str;
        }
        $conn->close();
        return "";
    }
    function doneorder($orderid){
        require 'dbconnect.php';
        //Reduce ingredients (Update ingredients stock)
        $sql = "SELECT * FROM placeorder a,dishing b,ingredients c WHERE ((a.orderid=".$orderid." AND a.hotid=".$_SESSION["hotelid"].") AND (b.hotid=a.hotid AND b.dishid=a.dishid)) AND (c.incid=b.ingrid AND c.hotid=a.hotid)";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                reduceIngr($row["ingrid"],$row["gram"],$row["qty"],$row["weight"]);
            }
        }
        $sql = "UPDATE placeorder SET process='done' WHERE orderid=".$orderid." AND hotid=".$_SESSION["hotelid"];
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $conn->close();
    }
    function reduceIngr($ingrid,$gram,$qty,$weight){
        require 'dbconnect.php';
        $reducestock = $weight * 1000;     //Kg -> Gram (Convert)
        $reducestock = $reducestock - ($gram * $qty);
        $reducestock /= 1000;     //Gram -> Kg (Convert)
        $sql = "UPDATE ingredients SET weight=".$reducestock." WHERE incid=".$ingrid." AND hotid=".$_SESSION["hotelid"];
        if (mysqli_query($conn, $sql)) {
            //echo "New record created successfully";
        } else {
            //echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        $conn->close();
    }
?>