<!DOCTYPE html>
<html>
<head>
	<title>Chef Login</title>
</head>
<body>
	<table class="formtable">
		<tr>
			<td colspan="3" class="warningerror" id="warning"></td>
		</tr>
		<tr>
			<th colspan="3" class="formhead">Staff Login</th>
		</tr>
	    <tr>
	        <th class="formcontent">Hotel</th>
	        <th class="formcontent">:</th>
	        <td><select id="hotel"></select></td>
	    </tr>
	    <tr>
	        <th class="formcontent">Username</th>
	        <th class="formcontent">:</th>
	        <td><input type='text' name='username' class="inputfield" /></td>
	    </tr>
	    <tr>
	    	<td></td><td></td><td id="username"></td>
	    </tr>
	    <tr>
	        <th class="formcontent">Password</th>
	        <th class="formcontent">:</th>
	        <td><input type='password' name='password' class="inputfield" /></td>
	    </tr>
	    <tr>
	    	<td></td><td></td><td id="password"></td>
	    </tr>
	    <tr>
	        <th colspan='3'><a name='logbutton' class="button" onclick="login(this.name)">Login</a></th>
	    </tr>
    </table>
</body>
<script type="text/javascript">
	$("#hotel").load("staff/logindb.php",{
		position : "others"
	});
	function login(bm) {
		if(bm == "logbutton"){
			var notempty1 = false;
			var notempty2 = false;
			if($("input[name~='username']").val() != ""){
				notempty1 = true;
				$("#username").html("");
			}
			if (!notempty1) {
				$("#username").html("Required");
			}
			if($("input[name~='password']").val() != ""){
				notempty2 = true;
				$("#password").html("");
			}
			if (!notempty2) {
				$("#password").html("Required");
			}
			if (notempty1 && notempty2) {
				$.post("staff/logindb.php",{
					username : $("input[name~='username']").val(),
					password : $("input[name~='password']").val(),
					hotelid : $( "#hotel option:selected" ).val()
				},
					function(result){
					    if(result == "done"){
					    	location.reload();
					    }else{
					    	$("#warning").html("Username or Password invalid !");
					    }
					}
				);
			}
		}
	}
</script>
</html>