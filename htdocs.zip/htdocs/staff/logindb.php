<?php
    session_start();
    if(isset($_POST["position"])){
        require 'dbconnect.php';
        $sql = 'SELECT * FROM hotel';
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)){
                echo "<option value='".$row["id"]."'>".$row["hotelname"]."</option>";
            }
        }
        $conn->close();
    }
    if(isset($_POST["username"]) && isset($_POST["password"]) && isset($_POST["hotelid"])){
        require 'dbconnect.php';
        $sql = 'SELECT * FROM staffacc WHERE (stname="'.$_POST["username"].'" AND stpassword="'.$_POST["password"].'") AND (sthotelid='.$_POST["hotelid"].' AND stposition="others")';
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0){
            $_SESSION["username"] = $_POST["username"];
            $_SESSION["password"] = $_POST["password"];
            $_SESSION["hotelid"] = $_POST["hotelid"];
            $_SESSION["who"] = "others";
            echo "done";
        }
        $conn->close();
    }
?>