<!DOCTYPE html>
<html>
<head>
	<title>Add Order</title>
</head>
<body>
	<table class="listtable">
		<tr>
			<td><input type="text" name="dishname" id="pldish" placeholder="Dish" list="srcdish" oninput="srcdish(this.name)" />
				<datalist id="srcdish"></datalist>
			</td>
			<td><input type="text" name="dishcount" id="pldishqty" onkeypress="return isNumberKey(event)" placeholder="Qty" oninput="getcost(this.name)" /></td>
			<td><input type="text" name="table_no" placeholder="Table.no"></td>
			<td>Price : <span id="price">0.00</span></td>
			<td id="existlist"></td>
		</tr>
		<tr>
			<td id="dishwar"></td>
			<td id="qtywar"></td>
			<td id="tablenowar"></td>
		</tr>
		<tr>
			<th colspan="2"><button name="addnxt" onclick="addnxt(this.name)">Dish +</button></th>
		</tr>
		<tr>
			<td id="items"></td>
			<td id="itemqty"></td>
			<td id="singleprice"></td>
			<td id="qtyprice"></td>
			<td id="removeitem"></td>
		</tr>
		<tr>
			<th>Total</th>
			<td colspan="2"></td>
			<td id="totalprice"></td>
		</tr>
		<tr>
			<td></td>
			<th><a name="placeorder" class="button" onclick="placeorder(this.name)">Place Order</a></th>
			<th><a name="resetorder" class="button" onclick="placeorder(this.name)">Reset</a></th>
		</tr>
	</table>
	<p id="load"></p>
</body>
<script type="text/javascript">
	var DishIdList = [], QtyList = [], DishPrice = [], tempPrice = 0.0, tempTotalPrice = 0.0;
	function isNumberKey(evt){
        var charsm = String.fromCharCode(evt.which || evt.keyCode);
        if(isNaN(charsm)){
            return false;
        }
        return true;
    }
	function srcdish(bm) {
		if (bm == "dishname") {
			$("#srcdish").load("staff/orderdb.php",{
				getdishname : $("input[name~='dishname']").val()
			});
		}
	}
	function getcost(bm){
		if(bm == "dishcount"){
			$.ajax({
				async:false,
				url: "staff/orderdb.php",
				type: "POST",
				data: {indishname : $("input[name~='dishname']").val(), inqty : $("input[name~='dishcount']").val()},
				success: function (result) {
					if (result != "invalid") {
						if(!(isNaN(Number(JSON.parse(result))))){
							tempPrice = Number(JSON.parse(result));
							$("#price").html(tempPrice);
						}
						
					}
					if (result == "invalid") {
						$("#dishwar").html("Dish Not Exist");
					}
				}
			});
		}
	}
	function addnxt(bm){
		if(bm == "addnxt"){
			let stop_ingr_overflow = false;
			if (($("#pldish").val() != "") && ($("#pldishqty").val() != "")) {
				$.ajax({
					async:false,
					url: "staff/orderdb.php",
					type: "POST",
					data: {pldish : $("#pldish").val(), pldishqty : $("#pldishqty").val()},
					success: function (result) {
						if (result == "done") {
							stop_ingr_overflow = true;
						} else {
							$("#qtywar").html("Stock Exceed !");
						}
					}
				});
			}
			if (stop_ingr_overflow) {
				var dishfield = false, qtyfield = false;
				if($("input[name~='dishname']").val() != ""){
					dishfield = true;
					$("#dishwar").html("");
				}
				if($("input[name~='dishcount']").val() != ""){
					qtyfield = true;
					$("#qtywar").html("");
				}
				if(!dishfield){
					$("#dishwar").html("Require");
				}
				if(!qtyfield){
					$("#qtywar").html("Require");
				}
				if (dishfield && qtyfield) {
					$.ajax({
						async:false,
						url: "staff/orderdb.php",
						type: "POST",
						data: {dishid : $("input[name~='dishname']").val()},
						success: function (result) {
							if (result != "invalid") {
								if(!(isNaN(Number(JSON.parse(result))))){
									//DishIdList,QtyList,DishPrice,tempPrice
									var existId = true, i = 0, disid = Number(JSON.parse(result)), listlength = DishIdList.length;
									while(i < DishIdList.length){
										if(DishIdList[i] == disid){
											existId = false;
											$("#existlist").html("This Dish already exist in your list !");
										}
										i++;
									}
									if (existId) {
										DishIdList[listlength] = disid;
										QtyList[listlength] = $("input[name~='dishcount']").val();
										DishPrice[listlength] = tempPrice;
										//items,itemqty,singleprice,qtyprice,removeitem,totalprice
										var str = "<span id='items"+DishIdList[listlength]+"'>"+$("input[name~='dishname']").val()+"</span><br>";
										$("#items").append(str);
										str = "<span id='itemqty"+DishIdList[listlength]+"'>"+$("input[name~='dishcount']").val()+"</span><br>";
										$("#itemqty").append(str);
										str = "<span id='singleprice"+DishIdList[listlength]+"'>"+(tempPrice / Number($("input[name~='dishcount']").val()))+"</span><br>";
										$("#singleprice").append(str);
										str = "<span id='qtyprice"+DishIdList[listlength]+"'>"+tempPrice+"</span><br>";
										$("#qtyprice").append(str);
										str = "<a name='removeitem"+DishIdList[listlength]+"' onclick='removeitem(this.name)'>Remove</a><br>";
										$("#removeitem").append(str);
										i = 0;
										tempTotalPrice = 0.0;
										while(i < DishIdList.length){
											tempTotalPrice += DishPrice[i];
											i++;
										}
										$("#totalprice").html(tempTotalPrice);
										$("#price").html("0");
										$("input[name~='dishname']").val("");
										$("input[name~='dishcount']").val("");
									}
								}
								
							}
							if (result == "invalid") {
								$("#dishwar").html("Dish Not Exist");
							}
						}
					});
				}
			}
		}
	}
	function removeitem(bm) {
		var bmname = bm.match(/[a-zA-Z]+/g);
		var bmid = bm.match(/(\d+)/g);
		if (bmname[0] == "removeitem") {
			var i = 0, listlength = DishIdList.length;
			while(i < DishIdList.length){
				if (DishIdList[i] == Number(bmid[0])) {
					var spans = "#items"+bmid[0];
					$(spans).next('br').remove();
					$(spans).remove();
					spans = "#itemqty"+bmid[0];
					$(spans).next('br').remove();
					$(spans).remove();
					spans = "#singleprice"+bmid[0];
					$(spans).next('br').remove();
					$(spans).remove();
					spans = "#qtyprice"+bmid[0];
					$(spans).next('br').remove();
					$(spans).remove();
					spans = "a[name~='removeitem"+bmid[0]+"']";
					$(spans).next('br').remove();
					$(spans).remove();
					tempTotalPrice -= DishPrice[i];
					$("#totalprice").html(tempTotalPrice);
					while(i < (listlength - 1)){
						DishIdList[i] = DishIdList[i+1];
						QtyList[i] = QtyList[i+1];
						DishPrice[i] = DishPrice[i+1];
						i++;
					}
					DishIdList.length = DishIdList.length - 1;
					QtyList.length = QtyList.length - 1;
					DishPrice.length = DishPrice.length - 1;
				}
				i++;
			}
		}
	}
	function placeorder(bm) {
		if (bm == "placeorder") {
			let stop_ingr_overflow = false;
			if (($("#pldish").val() != "") && ($("#pldishqty").val() != "")) {
				$.ajax({
					async:false,
					url: "staff/orderdb.php",
					type: "POST",
					data: {pldish : $("#pldish").val(), pldishqty : $("#pldishqty").val()},
					success: function (result) {
						if (result == "done") {
							stop_ingr_overflow = true;
						} else {
							$("#qtywar").html("Stock Exceed !");
						}
					}
				});
			}
			if (stop_ingr_overflow) {
				var dishfield = false, qtyfield = false, orderid = 0, tablenum = "", orderisplaced = false;
				var placetime = "<?php date_default_timezone_set('Asia/Kolkata'); echo date('Y-m-d H:i:s'); ?>";
				$.ajax({
					async:false,
					url: "staff/orderdb.php",
					type: "POST",
					data: {getorderid : "orderid"},
					success: function (result) {
						orderid = Number(JSON.parse(result));
					}
				});
				if($("input[name~='dishname']").val() != ""){
					dishfield = true;
					$("#dishwar").html("");
				}
				if($("input[name~='dishcount']").val() != ""){
					qtyfield = true;
					$("#qtywar").html("");
				}
				if(DishIdList.length <= 0){
					if(!dishfield){
						$("#dishwar").html("Require");
					}
					if(!qtyfield){
						$("#qtywar").html("Require");
					}
					if (dishfield && qtyfield){
						$.ajax({
							async:false,
							url: "staff/orderdb.php",
							type: "POST",
							data: {dishid : $("input[name~='dishname']").val()},
							success: function (result) {
								if (result != "invalid") {
									if(!(isNaN(Number(JSON.parse(result))))){
										var disid = Number(JSON.parse(result)), disqty = Number($("input[name~='dishcount']").val());
										if ($("input[name~='table_no']").val() != "") {
											orderisplaced = true;
											tablenum = $("input[name~='table_no']").val();
											orderplaced(orderid,disid,disqty,tempPrice,placetime,tablenum);
										} else {
											$("#tablenowar").html("Require");
										}
									}
								}
								if (result == "invalid") {
									$("#dishwar").html("Dish Not Exist");
								}
							}
						});
					}
				}
				if(DishIdList.length > 0){
					if(!dishfield){
						$("#dishwar").html("Require");
					}
					if(!qtyfield){
						$("#qtywar").html("Require");
					}
					if (dishfield && qtyfield){
						$.ajax({
							async:false,
							url: "staff/orderdb.php",
							type: "POST",
							data: {dishid : $("input[name~='dishname']").val()},
							success: function (result) {
								if (result != "invalid") {
									if(!(isNaN(Number(JSON.parse(result))))){
										var disid = Number(JSON.parse(result)), disqty = Number($("input[name~='dishcount']").val()), j = 0, fieldExistId = false;
										while(j < DishIdList.length){
											if (DishIdList[j] == disid) {
												fieldExistId = true;
											}
											if ($("input[name~='table_no']").val() != "") {
												orderisplaced = true;
												tablenum = $("input[name~='table_no']").val();
												orderplaced(orderid,DishIdList[j],QtyList[j],DishPrice[j],placetime,tablenum);
											} else {
												$("#tablenowar").html("Require");
											}
											j++;
										}
										if (!fieldExistId) {
											if ($("input[name~='table_no']").val() != "") {
												orderisplaced = true;
												tablenum = $("input[name~='table_no']").val();
												orderplaced(orderid,disid,disqty,tempPrice,placetime,tablenum);
											} else {
												$("#tablenowar").html("Require");
											}
										}
									}
								}
								if (result == "invalid") {
									$("#dishwar").html("Dish Not Exist");
								}
							}
						});
					}else{
						var j = 0;
						while(j < DishIdList.length){
							if ($("input[name~='table_no']").val() != "") {
								orderisplaced = true;
								tablenum = $("input[name~='table_no']").val();
								orderplaced(orderid,DishIdList[j],QtyList[j],DishPrice[j],placetime,tablenum);
							} else {
								$("#tablenowar").html("Require");
							}
							j++;
						}
					}
				}
				if (orderisplaced) {
					$("#warning").html("Success ...!");
					setTimeout(function(){location.reload(); }, 1000);
				}else{
					$("#warning").html("Order not placed ! Reset or Try again !");
				}
			}
		}
		if (bm == "resetorder") {
			location.reload();
		}
	}
	function orderplaced(orderid,disid,disqty,disqtyprice,placetime,tablenum) {
		$.post("staff/orderdb.php",{
			orderid : orderid, itemid : disid, itemqty : disqty, itemqtyprice : disqtyprice, placetime : placetime, tablenum : tablenum
		},function(result) {
			console.log(result);
		});
	}
</script>
</html>