notification();
var timerI = setInterval(notification ,20000);
function notification() {
	$("#cancelnoti").load("staff/notificationdb.php",{
		cancelnoti : "cancel"
	});
	$("#deliverynoti").load("staff/notificationdb.php",{
		deliverynoti : "delivery"
	});
}
function reset(){
	clearInterval(timerI);
	notification();
	timerI = setInterval(notification ,20000);
}