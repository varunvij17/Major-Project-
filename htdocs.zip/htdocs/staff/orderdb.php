<?php
    session_start();
    date_default_timezone_set('Asia/Kolkata');
    if(isset($_POST["getdishname"])){
    	getdishname($_POST["getdishname"]);
    }
    if(isset($_POST["pldish"]) && isset($_POST["pldishqty"])){
        dishqtyisok($_POST["pldish"], $_POST["pldishqty"]);
    }
    if(isset($_POST["dishid"])){
    	getdishid($_POST["dishid"]);
    }
    if(isset($_POST["getorderid"])){
    	getorderid();
    }
    if(isset($_POST["indishname"]) && isset($_POST["inqty"])){
    	getQtyCost($_POST["indishname"],$_POST["inqty"]);
    }
    if(isset($_POST["orderid"]) && isset($_POST["itemid"]) && isset($_POST["itemqty"]) && isset($_POST["itemqtyprice"]) && isset($_POST["placetime"]) && isset($_POST["tablenum"])){
    	orderplacing($_POST["orderid"],$_POST["itemid"],$_POST["itemqty"],$_POST["itemqtyprice"],$_POST["placetime"],$_POST["tablenum"]);
    }
    function dishqtyisok($pldish, $pldishqty) {
        $hotid = $_SESSION["hotelid"];
        $today = date("Ymd");
        require 'dbconnect.php';
        $sql = "SELECT * FROM dishes a, dishing b WHERE (a.dish='$pldish' AND a.hotid=$hotid) AND (b.hotid=$hotid AND b.dishid=a.disid)";
        $rowcount = mysqli_num_rows(mysqli_query($conn,$sql));
        $ingr_count = 0;
        if ($rowcount > 0) {
            $ingr_count = $rowcount;
        }
        $conn->close();
        require 'dbconnect.php';
        $ingr_qty = $pldishqty;
        $sql = "SELECT * FROM dishes a, placeorder b WHERE (a.dish='$pldish' AND a.hotid=$hotid) AND (b.hotid=$hotid AND (b.dishid=a.disid AND (b.process!='done' AND b.orderid LIKE '%$today%')))";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $ingr_qty += $row["qty"];
            }
        }/* else {
            echo "Error retrive qty record: " . mysqli_error($conn);
        }*/
        require 'dbconnect.php';
        $sql = "SELECT * FROM dishes a, dishing b, ingredients c WHERE (a.dish='$pldish' AND a.hotid=$hotid) AND (b.hotid=$hotid AND (b.dishid=a.disid AND (c.hotid=$hotid AND (c.incid=b.ingrid AND c.weight*1000>=b.gram*$ingr_qty))))";
        $rowcount = mysqli_num_rows(mysqli_query($conn,$sql));
        if (($rowcount > 0) && ($rowcount == $ingr_count)) {
            echo "done";
        } else {
            echo "invalid";
        }
        $conn->close();
    }
    function orderplacing($orderid,$dishid,$qty,$qtyprice,$placetime,$tablenum){
    	require 'dbconnect.php';
    	$sql = "INSERT INTO placeorder (orderid,hotid,tableno,dishid,qty,qtyprice,process,placetime) VALUES(".$orderid.",".$_SESSION["hotelid"].",".$tablenum.",".$dishid.",".$qty.",".$qtyprice.",'pending','".$placetime."')";
        if (mysqli_query($conn, $sql)) {
            //echo "Record updated successfully";
        } else {
            //echo "Error updating record: " . mysqli_error($conn);
        }
    	$conn->close();
    }
    function getorderid(){
    	require 'dbconnect.php';
    	$today = date("Ymd");
    	$sql = "SELECT DISTINCT orderid FROM placeorder WHERE orderid LIKE '%".$today."%' AND hotid=".$_SESSION["hotelid"];
        $rowcount = mysqli_num_rows(mysqli_query($conn,$sql));
        echo $today.$rowcount;
    	$conn->close();
    }
    function getQtyCost($dishname,$dishqty){
    	require 'dbconnect.php';
    	$sql = "SELECT price FROM dishes WHERE dish='".$dishname."' AND hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        if(mysqli_num_rows($result) > 0){
            $row = mysqli_fetch_assoc($result);
            echo $row["price"] * (float)$dishqty;
        }
        if ($rowcount <= 0) {
        	echo "invalid";
        }
    	$conn->close();
    }
    function getdishname($dishname) {
    	require 'dbconnect.php';
    	$sql = "SELECT * FROM dishes a, dishing b, ingredients c WHERE (a.dish LIKE '%$dishname%' AND (b.dishid=a.disid AND c.incid=b.ingrid)) AND a.hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        $str = "";
        $avoid_repeat = [];
        if(mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $tr = true;
                foreach ($avoid_repeat as $dish) {
                    if ($dish == $row["dish"]) {
                        $tr = false;
                    }
                }
                if ($tr) {
                    array_push($avoid_repeat, $row["dish"]);
                    $str .= "<option value='".$row["dish"]."'>".$row["dish"]."</option>";
                }
                if (($row["weight"] * 1000) < $row["gram"]) {
                    $conn->close();
                    echo $str = "<option value='Invalid'>Invalid</option>";
                    exit();
                }
            }
        }
        if ($rowcount <= 0) {
        	$str = "<option value='Invalid'>Invalid</option>";
        }
    	$conn->close();
        echo $str;
    }
    function getdishid($dishname){
    	require 'dbconnect.php';
        $sql = "SELECT * FROM dishes a, dishing b, ingredients c WHERE (a.dish='$dishname' AND (b.dishid=a.disid AND c.incid=b.ingrid)) AND a.hotid=".$_SESSION["hotelid"];
        $result = mysqli_query($conn,$sql);
        $rowcount = mysqli_num_rows($result);
        $str = 0;
        $avoid_repeat = [];
        if(mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                    $str = $row["disid"];
                if (($row["weight"] * 1000) < $row["gram"]) {
                    $conn->close();
                    echo "invalid";
                    exit();
                }
            }
        }
        if ($rowcount <= 0) {
        	echo "invalid";
            $conn->close();
            exit();
        }
    	echo $str;
    }
?>