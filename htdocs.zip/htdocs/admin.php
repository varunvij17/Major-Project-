<?php
    require "checkwho.php";
?>
<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="js/cookie.js"></script>
</head>
<body>
<header id="header" class="head">
	<?php
		require 'header.php';
	?>
</header>
	<p id="content1" class="content1"></p>
<footer id="footer">
	<?php
		require 'footer.php';
	?>
</footer>
</body>
<script type="text/javascript">
	$("#content1").load("admin/dashboard.php");
	document.getElementById("content1").style.marginTop = document.getElementById("header").clientHeight+"px";
	if(window.innerHeight > document.getElementById("content1").clientHeight){
		document.getElementById("content1").style.paddingBottom = (window.innerHeight-document.getElementById("content1").clientHeight)+"px";
	}
	document.getElementById("content1").style.marginBottom = "0px";
</script>
</html>